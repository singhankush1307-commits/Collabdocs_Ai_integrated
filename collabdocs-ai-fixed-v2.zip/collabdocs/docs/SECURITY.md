# CollabDocs Security Architecture & STRIDE Threat Model

CollabDocs is engineered from the ground up with a defense-in-depth security model adhering to OWASP Application Security Verification Standards (ASVS) and top-10 security best practices.

---

## 1. STRIDE Threat Model & Mitigations Summary

| Threat Category | Threat Description | Architectural Mitigation | Code Location |
| :--- | :--- | :--- | :--- |
| **Spoofing** | Attacker impersonates valid user via stolen token or credentials | Short-lived (15m) cryptographically signed JWT access tokens; 7-day rotating refresh tokens with automatic reuse detection (entire token family revoked on reuse); bcrypt password hashing (cost factor 12). | `server/src/services/authService.js`<br>`server/src/utils/security.js` |
| **Tampering** | Unauthorized modifications to documents or intercepted socket events | Server-enforced Role-Based Access Control (RBAC: Owner, Editor, Commenter, Viewer) on **both** REST endpoints and Socket.io events. Viewers attempting to send CRDT binary updates are rejected, logged, and alerted. Cryptographic SHA-256 token hashing for share links and refresh tokens. | `server/src/socket/yjsSocketServer.js`<br>`server/src/services/permissionService.js` |
| **Repudiation** | User denies performing destructive actions (e.g., document deletion, permissions alteration) | Persistent append-only Security Audit Trail (`AuditLog` collection) logging user ID, IP address, user agent, target resource, and action details with automated 90-day TTL. Immutable document version history tracking every manual and auto snapshot. | `server/src/models/AuditLog.js`<br>`server/src/services/auditService.js` |
| **Information Disclosure** | Credential harvesting, user enumeration, database leakage, XSS | Generic login failure messages (`"Invalid email or password"`) with constant-time dummy comparisons to eliminate timing side-channels; Helmet CSP and security headers; httpOnly, Secure, SameSite=Strict cookies; masked 500 errors in production. | `server/src/services/authService.js`<br>`server/src/app.js` |
| **Denial of Service** | Brute force login attacks, rate abuse, Socket.io payload flooding | `express-rate-limit` on authentication (15 requests/15m) and AI routes (20 requests/min); progressive account lockout after 5 failed attempts (15-minute lock); per-socket rate limit (60 msgs/sec); max message size cap (100 KB); request body size limit (2 MB). | `server/src/routes/authRoutes.js`<br>`server/src/socket/yjsSocketServer.js` |
| **Elevation of Privilege** | Viewers altering document, editors deleting document, horizontal tenant bypass | Multi-tiered permission verification middleware on every route (`requireDocPermission('owner' | 'editor' | 'viewer')`); database queries always filtered by authenticated `owner` or `collaborators.user`. | `server/src/services/permissionService.js`<br>`server/src/controllers/documentController.js` |

---

## 2. Authentication & Session Management

### 2.1 Password Hashing & Complexity Policy
- Passwords hashed using **bcrypt** with a work factor cost of **12** (preventing rainbow table and hardware acceleration attacks).
- Enforced password policy: minimum 8 characters, at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special symbol.
- Constant-time dummy hash comparison is executed if an email does not exist, denying attackers the ability to measure response timing to enumerate valid accounts.

### 2.2 Token Architecture & Refresh Token Family Rotation
- **Access Tokens:** Signed with HMAC-SHA256, 15-minute expiration, transmitted strictly via the HTTP `Authorization: Bearer <token>` header.
- **Refresh Tokens:** Cryptographically random 40-byte tokens, 7-day expiration, stored strictly in `httpOnly`, `Secure` (in production), `SameSite=Strict` cookies.
- **Database Storage:** Only the **SHA-256 hash** of refresh tokens is persisted in MongoDB (`User.refreshTokens.tokenHash`). The raw token is never stored in plain text.
- **Reuse Detection:** Every login session is assigned a unique `familyId`. When a refresh token is used, it is rotated and marked as revoked. If an attacker replays an already-revoked refresh token, the server immediately triggers an intrusion alert, logs an audit event, and revokes the **entire family**, instantly locking out the attacker and protecting the user.

### 2.3 Account Lockout & Progressive Delay
- Consecutive failed login attempts increment `failedLoginAttempts`.
- Upon 5 consecutive failed attempts, `lockUntil` is set for 15 minutes, blocking all login attempts with HTTP `429 Too Many Requests`.
- A successful login resets `failedLoginAttempts` and clears `lockUntil`.

---

## 3. Real-Time Socket.io & CRDT Security

### 3.1 Handshake Authentication
Every WebSocket connection must authenticate during the handshake via `socket.handshake.auth.token`. Handshakes with missing or invalid JWTs are immediately terminated with an error before any socket events can be registered.

### 3.2 Granular RBAC on Collaborative Updates
When a user joins a document room (`join-document`), the server checks the document’s owner and collaborator list in MongoDB.
- **Owners & Editors:** Permitted to send and receive Yjs binary updates.
- **Viewers:** Given read-only access. If a viewer client emits a `sync-message` containing a write update (SyncStep2 or Update), the server:
  1. Rejects the update immediately.
  2. Emits a `permission-error` event to the offending socket.
  3. Logs a `DOC_UNAUTHORIZED_WRITE_REJECTED` security audit event with client IP and user identity.
  4. Never persists or broadcasts the unauthorized update.

### 3.3 Socket Abuse & Flood Protection
- **Per-Socket Rate Limiting:** Each socket connection tracks update throughput. Clients sending more than 60 updates per second are disconnected automatically.
- **Payload Size Caps:** Any binary message exceeding 100 KB is discarded.

---

## 4. AI Security & Prompt Injection Defense

1. **Server-Side API Key Sequestration:** The LLM API key is managed purely server-side via environment variables (`AI_API_KEY`) and is never sent to the client.
2. **Access Control:** Only users with `Editor` or `Owner` roles can invoke AI endpoints (`POST /api/ai/transform`).
3. **Prompt Injection Delimiters:** User text is sanitized, capped at 5,000 characters, and encapsulated in strict delimiters:
   ```
   <DOCUMENT_CONTENT>
   ... untrusted user text ...
   </DOCUMENT_CONTENT>
   ```
4. **Hardened System Prompt:** The LLM is explicitly instructed to treat everything within the delimiters as inert data and to ignore all embedded commands or instructions.
5. **Untrusted Output Sanitization:** The returned text is sanitized with **DOMPurify** (`isomorphic-dompurify`) before being delivered to the client, preventing stored XSS via AI hallucinations.
6. **Rate Limiting & Daily Quota:** Enforced both by IP/user via `express-rate-limit` (20 req/min) and by user record (`50 requests/day`).

---

## 5. Network & Browser Hardening

- **Content Security Policy (CSP):** Configured via Helmet to disallow inline untrusted script execution.
- **CORS:** Whitelisted strictly to approved client origins (`CLIENT_URL`).
- **CSRF Defense:** State-changing authentication requests (refresh, logout) enforce `SameSite=Strict` cookies and verify a custom application header (`X-Requested-With: CollabDocs`).
- **Parameter Pollution:** `hpp` middleware protects against HTTP parameter pollution.
- **NoSQL Injection Defense:** Strict Mongoose schemas with type casting and Zod validation on all input routes.

