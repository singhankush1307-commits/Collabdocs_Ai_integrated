# Troubleshooting

## `POST /api/auth/register 500 (Internal Server Error)`
Vite's dev proxy returns a bare 500 when it cannot reach the API server.
1. Start MongoDB (`docker compose up -d mongo`) and copy `.env.example` to `.env`.
2. Start the server (`npm run dev:server`) and confirm http://127.0.0.1:5000/api/health responds.
3. The proxy now targets `127.0.0.1` (not `localhost`) to avoid IPv6 `::1` resolution problems.
