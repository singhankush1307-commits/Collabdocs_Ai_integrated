import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    globals: true,
    testTimeout: 60000,
    hookTimeout: 360000,
    setupFiles: [],
    include: ['tests/**/*.test.js'],
  },
});
