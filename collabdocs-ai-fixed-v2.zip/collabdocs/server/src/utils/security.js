import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import DOMPurify from 'isomorphic-dompurify';
import { env } from '../config/env.js';

const BCRYPT_ROUNDS = 12;

// Password hashing with bcrypt cost 12
export async function hashPassword(plainPassword) {
  return bcrypt.hash(plainPassword, BCRYPT_ROUNDS);
}

export async function comparePassword(plainPassword, hashedPassword) {
  return bcrypt.compare(plainPassword, hashedPassword);
}

// SHA-256 hash for secure storage of refresh tokens and share links
export function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// Generate cryptographically secure random token (64 hex chars)
export function generateSecureToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

// JWT Access Token Generation (15 min)
export function generateAccessToken(payload) {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, {
    expiresIn: env.JWT_ACCESS_EXPIRES_IN,
  });
}

// JWT Access Token Verification
export function verifyAccessToken(token) {
  return jwt.verify(token, env.JWT_ACCESS_SECRET);
}

// Generate Refresh Token with expiry
export function generateRefreshToken() {
  const token = generateSecureToken(40);
  const expiresAt = new Date(Date.now() + env.JWT_REFRESH_EXPIRES_DAYS * 24 * 60 * 60 * 1000);
  return { token, expiresAt };
}

// Password Policy Enforcement
// Minimum 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special character
export function validatePasswordPolicy(password) {
  if (typeof password !== 'string') return false;
  if (password.length < 8) return false;
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasDigit = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);
  return hasUpper && hasLower && hasDigit && hasSpecial;
}

// Sanitize rich text / HTML to defend against stored XSS
export function sanitizeHtml(dirtyHtml) {
  if (!dirtyHtml || typeof dirtyHtml !== 'string') return '';
  return DOMPurify.sanitize(dirtyHtml, {
    ALLOWED_TAGS: [
      'p', 'b', 'i', 'em', 'strong', 'a', 'h1', 'h2', 'h3', 'h4', 
      'ul', 'ol', 'li', 'code', 'pre', 'blockquote', 'table', 
      'thead', 'tbody', 'tr', 'th', 'td', 'br', 'span'
    ],
    ALLOWED_ATTR: ['href', 'title', 'target', 'rel', 'class', 'style'],
  });
}

