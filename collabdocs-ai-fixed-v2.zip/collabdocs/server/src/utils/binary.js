export function toUint8Array(data) {
  if (!data) return new Uint8Array(0);
  
  // If it's already a standard Uint8Array and NOT a Node.js Buffer
  if (data.constructor === Uint8Array) {
    return data;
  }

  // If it's a Node Buffer or Mongo Binary
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(data.buffer || data);
  return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
}

export function toBuffer(uint8) {
  if (!uint8) return Buffer.alloc(0);
  if (Buffer.isBuffer(uint8)) return uint8;
  return Buffer.from(uint8.buffer, uint8.byteOffset, uint8.byteLength);
}

