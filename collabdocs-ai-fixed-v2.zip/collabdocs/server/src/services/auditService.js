import { AuditLog } from '../models/AuditLog.js';
import { logger } from '../utils/logger.js';

export async function logSecurityEvent({ event, userId = null, targetId = null, req = null, details = {} }) {
  try {
    const ip = req?.ip || req?.headers?.['x-forwarded-for'] || req?.socket?.remoteAddress || null;
    const userAgent = req?.headers?.['user-agent'] || null;

    const entry = await AuditLog.create({
      event,
      userId,
      targetId,
      ip,
      userAgent,
      details,
    });

    logger.info(
      { auditEvent: event, userId, targetId, ip },
      `Security Audit Log: ${event}`
    );

    return entry;
  } catch (err) {
    // Audit logging should not crash the primary flow, but must be logged to stderr
    logger.error(err, `Failed to record audit log event: ${event}`);
    return null;
  }
}

