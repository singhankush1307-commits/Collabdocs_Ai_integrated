import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import {
  hashPassword,
  comparePassword,
  hashToken,
  generateRefreshToken,
  generateAccessToken,
  validatePasswordPolicy,
} from '../utils/security.js';
import {
  BadRequestError,
  UnauthorizedError,
  ConflictError,
  TooManyRequestsError,
} from '../utils/errors.js';
import { logSecurityEvent } from './auditService.js';

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_TIME_MS = 15 * 60 * 1000; // 15 minutes lockout

// Dummy hash for constant-time comparison against timing attacks when user does not exist.
// Generated with bcryptjs so it is always a structurally valid bcrypt hash.
const DUMMY_HASH = bcrypt.hashSync('collabdocs-dummy-password', 12);

export async function registerUser({ email, password, name }, req) {
  if (!validatePasswordPolicy(password)) {
    throw new BadRequestError(
      'Password does not meet complexity requirements. It must contain at least 8 characters, with uppercase, lowercase, numbers, and special characters.'
    );
  }

  const normalizedEmail = email.toLowerCase().trim();
  const existingUser = await User.findOne({ email: normalizedEmail });
  if (existingUser) {
    throw new ConflictError('An account with this email address already exists');
  }

  const passwordHash = await hashPassword(password);
  const user = await User.create({
    email: normalizedEmail,
    passwordHash,
    name: name.trim(),
  });

  // Create initial refresh token family
  const familyId = crypto.randomUUID();
  const { token: rawRefreshToken, expiresAt } = generateRefreshToken();
  const tokenHash = hashToken(rawRefreshToken);

  user.refreshTokens.push({
    tokenHash,
    familyId,
    expiresAt,
    isRevoked: false,
  });
  await user.save();

  const accessToken = generateAccessToken({
    userId: user._id.toString(),
    email: user.email,
    name: user.name,
  });

  await logSecurityEvent({
    event: 'AUTH_REGISTER_SUCCESS',
    userId: user._id,
    targetId: user._id.toString(),
    req,
    details: { email: user.email },
  });

  return {
    user: {
      id: user._id.toString(),
      email: user.email,
      name: user.name,
      avatarColor: user.avatarColor,
    },
    accessToken,
    refreshToken: rawRefreshToken,
  };
}

export async function loginUser({ email, password }, req) {
  const normalizedEmail = email.toLowerCase().trim();
  const user = await User.findOne({ email: normalizedEmail });

  // If user not found, perform dummy comparison to prevent user enumeration via timing
  if (!user) {
    await comparePassword(password, DUMMY_HASH);
    await logSecurityEvent({
      event: 'AUTH_LOGIN_FAILED',
      req,
      details: { email: normalizedEmail, reason: 'user_not_found' },
    });
    throw new UnauthorizedError('Invalid email or password');
  }

  // Check account lockout
  if (user.isLocked) {
    const remainingMinutes = Math.ceil((user.lockUntil.getTime() - Date.now()) / (60 * 1000));
    await logSecurityEvent({
      event: 'AUTH_LOGIN_BLOCKED_LOCKOUT',
      userId: user._id,
      req,
      details: { email: user.email, remainingMinutes },
    });
    throw new TooManyRequestsError(
      `Account is temporarily locked due to repeated failed attempts. Please try again in ${remainingMinutes} minute(s).`
    );
  }

  const isPasswordValid = await comparePassword(password, user.passwordHash);

  if (!isPasswordValid) {
    user.failedLoginAttempts += 1;
    if (user.failedLoginAttempts >= MAX_FAILED_ATTEMPTS) {
      user.lockUntil = new Date(Date.now() + LOCK_TIME_MS);
      await user.save();
      await logSecurityEvent({
        event: 'AUTH_ACCOUNT_LOCKED',
        userId: user._id,
        req,
        details: { email: user.email, failedAttempts: user.failedLoginAttempts },
      });
      throw new TooManyRequestsError(
        'Too many failed login attempts. Account is locked for 15 minutes.'
      );
    }

    await user.save();
    await logSecurityEvent({
      event: 'AUTH_LOGIN_FAILED',
      userId: user._id,
      req,
      details: { email: user.email, failedAttempts: user.failedLoginAttempts },
    });
    throw new UnauthorizedError('Invalid email or password');
  }

  // Login successful: reset failed attempts
  user.failedLoginAttempts = 0;
  user.lockUntil = null;

  // Generate new refresh token family for this login session
  const familyId = crypto.randomUUID();
  const { token: rawRefreshToken, expiresAt } = generateRefreshToken();
  const tokenHash = hashToken(rawRefreshToken);

  user.refreshTokens.push({
    tokenHash,
    familyId,
    expiresAt,
    isRevoked: false,
  });

  // Keep refresh token array reasonably sized (clean up expired or old revoked tokens)
  if (user.refreshTokens.length > 50) {
    user.refreshTokens = user.refreshTokens.filter(
      (t) => !t.isRevoked && t.expiresAt > new Date()
    );
  }

  await user.save();

  const accessToken = generateAccessToken({
    userId: user._id.toString(),
    email: user.email,
    name: user.name,
  });

  await logSecurityEvent({
    event: 'AUTH_LOGIN_SUCCESS',
    userId: user._id,
    targetId: user._id.toString(),
    req,
    details: { email: user.email },
  });

  return {
    user: {
      id: user._id.toString(),
      email: user.email,
      name: user.name,
      avatarColor: user.avatarColor,
    },
    accessToken,
    refreshToken: rawRefreshToken,
  };
}

export async function refreshAccessToken(rawRefreshToken, req) {
  if (!rawRefreshToken) {
    throw new UnauthorizedError('Refresh token required');
  }

  const incomingHash = hashToken(rawRefreshToken);
  const user = await User.findOne({ 'refreshTokens.tokenHash': incomingHash });

  if (!user) {
    throw new UnauthorizedError('Invalid refresh token');
  }

  const tokenRecord = user.refreshTokens.find((t) => t.tokenHash === incomingHash);
  if (!tokenRecord) {
    throw new UnauthorizedError('Invalid refresh token');
  }

  // Token reuse detection! If already revoked, attack suspected: revoke entire family!
  if (tokenRecord.isRevoked) {
    const familyId = tokenRecord.familyId;
    user.refreshTokens.forEach((t) => {
      if (t.familyId === familyId) {
        t.isRevoked = true;
      }
    });
    await user.save();

    await logSecurityEvent({
      event: 'AUTH_REFRESH_TOKEN_REUSE_DETECTED',
      userId: user._id,
      req,
      details: { familyId, email: user.email },
    });

    throw new UnauthorizedError('Security alert: Refresh token reuse detected. All sessions revoked.');
  }

  // Check expiration
  if (tokenRecord.expiresAt < new Date()) {
    tokenRecord.isRevoked = true;
    await user.save();
    throw new UnauthorizedError('Refresh token has expired');
  }

  // Mark current token as used / revoked
  tokenRecord.isRevoked = true;

  // Issue rotated refresh token under the same family
  const { token: newRawRefreshToken, expiresAt } = generateRefreshToken();
  const newTokenHash = hashToken(newRawRefreshToken);

  user.refreshTokens.push({
    tokenHash: newTokenHash,
    familyId: tokenRecord.familyId,
    expiresAt,
    isRevoked: false,
  });

  await user.save();

  const accessToken = generateAccessToken({
    userId: user._id.toString(),
    email: user.email,
    name: user.name,
  });

  return {
    accessToken,
    refreshToken: newRawRefreshToken,
    user: {
      id: user._id.toString(),
      email: user.email,
      name: user.name,
      avatarColor: user.avatarColor,
    },
  };
}

export async function logoutUser(rawRefreshToken, req) {
  if (!rawRefreshToken) return;

  const incomingHash = hashToken(rawRefreshToken);
  const user = await User.findOne({ 'refreshTokens.tokenHash': incomingHash });
  if (user) {
    const tokenRecord = user.refreshTokens.find((t) => t.tokenHash === incomingHash);
    if (tokenRecord) {
      tokenRecord.isRevoked = true;
      await user.save();
      await logSecurityEvent({
        event: 'AUTH_LOGOUT',
        userId: user._id,
        req,
      });
    }
  }
}

export async function logoutAllDevices(userId, req) {
  const user = await User.findById(userId);
  if (user) {
    user.refreshTokens.forEach((t) => {
      t.isRevoked = true;
    });
    await user.save();
    await logSecurityEvent({
      event: 'AUTH_LOGOUT_ALL',
      userId: user._id,
      req,
    });
  }
}

