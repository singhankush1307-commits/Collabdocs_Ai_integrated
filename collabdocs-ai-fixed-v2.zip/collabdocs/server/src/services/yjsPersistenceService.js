import * as Y from 'yjs';
import { Document } from '../models/Document.js';
import { DocumentSnapshot } from '../models/DocumentSnapshot.js';
import { DocumentUpdate } from '../models/DocumentUpdate.js';
import { toUint8Array, toBuffer } from '../utils/binary.js';
import { logger } from '../utils/logger.js';
import { NotFoundError, BadRequestError } from '../utils/errors.js';
import { logSecurityEvent } from './auditService.js';

const COMPACT_UPDATE_THRESHOLD = 50; // Compact every 50 incremental updates

// Active in-memory document state cache: docId -> { ydoc, updateCount, pendingUpdates: [] }
const docCache = new Map();

export async function getOrLoadDoc(documentId) {
  const idStr = documentId.toString();
  if (docCache.has(idStr)) {
    return docCache.get(idStr);
  }

  const ydoc = new Y.Doc();

  // 1. Fetch latest snapshot
  const latestSnapshot = await DocumentSnapshot.findOne({ documentId })
    .sort({ version: -1 })
    .lean();

  let snapshotTime = new Date(0);
  let currentVersion = 1;

  if (latestSnapshot && latestSnapshot.snapshot) {
    Y.applyUpdate(ydoc, toUint8Array(latestSnapshot.snapshot));
    snapshotTime = latestSnapshot.createdAt;
    currentVersion = latestSnapshot.version;
  }

  // 2. Fetch all incremental updates since the snapshot
  const updates = await DocumentUpdate.find({
    documentId,
    createdAt: { $gte: snapshotTime },
  })
    .sort({ createdAt: 1 })
    .lean();

  for (const record of updates) {
    if (record.update) {
      try {
        Y.applyUpdate(ydoc, toUint8Array(record.update));
      } catch (err) {
        logger.error({ err, documentId, updateId: record._id }, 'Failed to apply incremental update');
      }
    }
  }

  const cacheEntry = {
    ydoc,
    currentVersion,
    updateCount: updates.length,
    lastActivity: Date.now(),
    saveTimeout: null,
    pendingBatch: [],
  };

  docCache.set(idStr, cacheEntry);
  return cacheEntry;
}

// Persist incremental update (debounced batch insertion)
export async function persistUpdate(documentId, updateBuffer, origin = null) {
  const idStr = documentId.toString();
  let entry = docCache.get(idStr);

  if (!entry) {
    entry = await getOrLoadDoc(documentId);
  }

  const uint8 = toUint8Array(updateBuffer);

  // Apply to in-memory Y.Doc
  Y.applyUpdate(entry.ydoc, uint8, origin);
  entry.updateCount += 1;
  entry.lastActivity = Date.now();

  // Push to pending batch
  entry.pendingBatch.push({
    documentId,
    update: toBuffer(uint8),
    origin,
    createdAt: new Date(),
  });

  // Debounce batch insertion to DB (flush every 200ms or when batch exceeds 10)
  if (!entry.saveTimeout) {
    entry.saveTimeout = setTimeout(async () => {
      await flushPendingUpdates(documentId);
    }, 200);
  }

  if (entry.pendingBatch.length >= 10) {
    clearTimeout(entry.saveTimeout);
    entry.saveTimeout = null;
    await flushPendingUpdates(documentId);
  }

  // Check if compaction threshold is reached
  if (entry.updateCount >= COMPACT_UPDATE_THRESHOLD) {
    compactDocument(documentId).catch((err) =>
      logger.error({ err, documentId }, 'Background compaction failed')
    );
  }
}

// Flush pending updates to MongoDB
export async function flushPendingUpdates(documentId) {
  const idStr = documentId.toString();
  const entry = docCache.get(idStr);
  if (!entry || entry.pendingBatch.length === 0) return;

  const toSave = [...entry.pendingBatch];
  entry.pendingBatch = [];
  entry.saveTimeout = null;

  try {
    await DocumentUpdate.insertMany(toSave, { ordered: false });
    await Document.updateOne({ _id: documentId }, { updatedAt: new Date() });
  } catch (err) {
    logger.error({ err, documentId, count: toSave.length }, 'Failed to insert pending updates batch');
    // Re-queue failed items at beginning
    entry.pendingBatch.unshift(...toSave);
  }
}

// Flush all cached writes and flush when last client disconnects
export async function flushAndEvictDoc(documentId) {
  await flushPendingUpdates(documentId);
  const idStr = documentId.toString();
  docCache.delete(idStr);
}

// Compact incremental updates into a single snapshot
export async function compactDocument(documentId, label = '', userId = null, isManual = false) {
  const entry = await getOrLoadDoc(documentId);
  await flushPendingUpdates(documentId);

  const docRecord = await Document.findById(documentId);
  if (!docRecord) throw new NotFoundError('Document not found');

  const newVersion = (docRecord.currentVersion || 1) + 1;
  const compactedBinary = Y.encodeStateAsUpdate(entry.ydoc);

  const snapshot = await DocumentSnapshot.create({
    documentId,
    snapshot: toBuffer(compactedBinary),
    version: newVersion,
    label: label || (isManual ? `Version ${newVersion}` : `Auto-snapshot v${newVersion}`),
    createdBy: userId,
    isManual,
    createdAt: new Date(),
  });

  docRecord.currentVersion = newVersion;
  docRecord.lastCompactedAt = new Date();
  await docRecord.save();

  entry.currentVersion = newVersion;
  entry.updateCount = 0;

  // Prune older incremental updates that were created before this snapshot
  // Keep 5 most recent updates for safety buffer
  const cutoffTime = new Date(Date.now() - 5000);
  await DocumentUpdate.deleteMany({
    documentId,
    createdAt: { $lt: cutoffTime },
  });

  logger.info(
    { documentId, version: newVersion, isManual, bytes: compactedBinary.byteLength },
    'Document compacted into snapshot successfully'
  );

  return snapshot;
}

// Restore a historical version (creates a new snapshot with restored content)
export async function restoreVersion(documentId, versionNumber, userId, req = null) {
  const targetSnapshot = await DocumentSnapshot.findOne({
    documentId,
    version: versionNumber,
  });

  if (!targetSnapshot) {
    throw new NotFoundError(`Version ${versionNumber} not found`);
  }

  const docRecord = await Document.findById(documentId);
  if (!docRecord) throw new NotFoundError('Document not found');

  // Create temporary doc to decode snapshot
  const restoredDoc = new Y.Doc();
  Y.applyUpdate(restoredDoc, toUint8Array(targetSnapshot.snapshot));
  const restoredState = Y.encodeStateAsUpdate(restoredDoc);

  // Update in-memory cached doc if loaded
  const idStr = documentId.toString();
  let entry = docCache.get(idStr);
  if (entry) {
    // Clear and re-apply
    entry.ydoc = restoredDoc;
  }

  // Create new snapshot indicating restored state
  const newVersion = (docRecord.currentVersion || 1) + 1;
  const snapshot = await DocumentSnapshot.create({
    documentId,
    snapshot: toBuffer(restoredState),
    version: newVersion,
    label: `Restored from Version ${versionNumber}`,
    createdBy: userId,
    isManual: true,
    createdAt: new Date(),
  });

  // Also record as a document update so all connected clients receive the restored state
  await persistUpdate(documentId, toBuffer(restoredState), 'restore');
  await flushPendingUpdates(documentId);

  docRecord.currentVersion = newVersion;
  await docRecord.save();

  await logSecurityEvent({
    event: 'DOC_VERSION_RESTORED',
    userId,
    targetId: documentId.toString(),
    req,
    details: { restoredFromVersion: versionNumber, newVersion },
  });

  return snapshot;
}

// Get list of versions for side panel
export async function getVersionList(documentId) {
  const snapshots = await DocumentSnapshot.find({ documentId })
    .sort({ version: -1 })
    .populate('createdBy', 'name email avatarColor')
    .lean();

  return snapshots.map((s) => ({
    id: s._id.toString(),
    version: s.version,
    label: s.label,
    isManual: s.isManual,
    createdBy: s.createdBy || { name: 'System Auto-Save', email: '' },
    createdAt: s.createdAt,
    sizeBytes: s.snapshot?.byteLength || 0,
  }));
}

// Read-only text / state preview of a version
export async function getVersionContent(documentId, versionNumber) {
  const snapshot = await DocumentSnapshot.findOne({
    documentId,
    version: versionNumber,
  });

  if (!snapshot) {
    throw new NotFoundError(`Version ${versionNumber} not found`);
  }

  const tempDoc = new Y.Doc();
  Y.applyUpdate(tempDoc, toUint8Array(snapshot.snapshot));

  // Extract text or fragment
  const ytext = tempDoc.getText('prosemirror');
  const yxml = tempDoc.getXmlFragment('prosemirror');

  return {
    version: snapshot.version,
    label: snapshot.label,
    createdAt: snapshot.createdAt,
    rawText: ytext.toString(),
    snapshotBase64: Buffer.from(snapshot.snapshot).toString('base64'),
  };
}
