import { AppError } from '../utils/errors.js';

const DEFAULT_TIMEOUT_MS = 30000;

function shorten(text, max = 200) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  return s.length > max ? `${s.slice(0, max)}…` : s;
}

// Turn an upstream HTTP failure into a clear, actionable error for the UI.
function upstreamError(provider, status, body) {
  const apiMsg = shorten(body?.error?.message || (typeof body === 'string' ? body : ''));
  let httpStatus = 502;
  let message;

  if ((status === 400 && /api key/i.test(apiMsg)) || status === 401 || status === 403) {
    message = `${provider} rejected the API key. Check AI_API_KEY in your .env file and restart the server.`;
  } else if (status === 404) {
    message = `${provider} could not find the model. Check AI_MODEL_NAME in your .env file.`;
  } else if (status === 429) {
    httpStatus = 429;
    message = `${provider} rate limit or quota reached. Wait a minute and try again.`;
  } else {
    message = `${provider} request failed (status ${status}).${apiMsg ? ` ${apiMsg}` : ''}`;
  }

  return new AppError(message, httpStatus, 'AI_PROVIDER_ERROR');
}

async function postJson(provider, url, { headers, body, fetchImpl, timeoutMs }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    let res;
    try {
      res = await fetchImpl(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...headers },
        signal: controller.signal,
        body: JSON.stringify(body),
      });
    } catch (err) {
      if (err?.name === 'AbortError') {
        throw new AppError(`${provider} took too long to respond. Please try again.`, 504, 'AI_TIMEOUT');
      }
      throw new AppError(
        `Could not reach ${provider}. Check your internet connection.`,
        502,
        'AI_UNREACHABLE'
      );
    }

    const raw = await res.text();
    let data = null;
    try {
      data = raw ? JSON.parse(raw) : null;
    } catch {
      data = raw;
    }

    if (!res.ok) throw upstreamError(provider, res.status, data);
    return data;
  } finally {
    clearTimeout(timer);
  }
}

export async function callGemini({
  apiKey,
  model,
  systemInstruction,
  userContent,
  fetchImpl = fetch,
  timeoutMs = DEFAULT_TIMEOUT_MS,
}) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

  const data = await postJson('Gemini', url, {
    headers: { 'x-goog-api-key': apiKey },
    fetchImpl,
    timeoutMs,
    body: {
      systemInstruction: { parts: [{ text: systemInstruction }] },
      contents: [{ role: 'user', parts: [{ text: userContent }] }],
      generationConfig: { temperature: 0.3, maxOutputTokens: 4096 },
    },
  });

  const candidate = data?.candidates?.[0];
  const text = (candidate?.content?.parts || [])
    .filter((p) => typeof p.text === 'string' && !p.thought)
    .map((p) => p.text)
    .join('');

  if (!text.trim()) {
    const reason = data?.promptFeedback?.blockReason || candidate?.finishReason || 'unknown';
    throw new AppError(
      `Gemini returned no text (reason: ${reason}). Try selecting different text.`,
      422,
      'AI_EMPTY_RESPONSE'
    );
  }
  return text;
}

export async function callOpenAI({
  apiKey,
  model,
  systemInstruction,
  userContent,
  fetchImpl = fetch,
  timeoutMs = DEFAULT_TIMEOUT_MS,
}) {
  const data = await postJson('OpenAI', 'https://api.openai.com/v1/chat/completions', {
    headers: { Authorization: `Bearer ${apiKey}` },
    fetchImpl,
    timeoutMs,
    body: {
      model,
      messages: [
        { role: 'system', content: systemInstruction },
        { role: 'user', content: userContent },
      ],
    },
  });

  const text = data?.choices?.[0]?.message?.content || '';
  if (!text.trim()) {
    throw new AppError('OpenAI returned no text. Try selecting different text.', 422, 'AI_EMPTY_RESPONSE');
  }
  return text;
}
