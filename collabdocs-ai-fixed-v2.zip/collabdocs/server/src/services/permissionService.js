import { Document } from '../models/Document.js';
import { NotFoundError, ForbiddenError } from '../utils/errors.js';

export const ROLE_HIERARCHY = {
  owner: 4,
  editor: 3,
  commenter: 2,
  viewer: 1,
};

export function hasRequiredRole(userRole, requiredRole) {
  if (!userRole || !requiredRole) return false;
  const userLevel = ROLE_HIERARCHY[userRole.toLowerCase()] || 0;
  const requiredLevel = ROLE_HIERARCHY[requiredRole.toLowerCase()] || 0;
  return userLevel >= requiredLevel;
}

export function resolveUserRole(doc, userId) {
  if (!doc || !userId) return null;
  const normalizedUserId = userId.toString();

  // Check if owner
  if (doc.owner.toString() === normalizedUserId) {
    return 'owner';
  }

  // Check collaborator list
  const collaborator = doc.collaborators.find(
    (c) => c.user && c.user.toString() === normalizedUserId
  );
  if (collaborator) {
    return collaborator.role;
  }

  return null;
}

export async function checkDocumentAccess(docId, userId, requiredRole = 'viewer') {
  const doc = await Document.findById(docId);
  if (!doc || doc.isDeleted) {
    throw new NotFoundError('Document not found');
  }

  const role = resolveUserRole(doc, userId);
  if (!role || !hasRequiredRole(role, requiredRole)) {
    throw new ForbiddenError(
      `Insufficient permissions. '${requiredRole}' role required, but your role is '${role || 'none'}'.`
    );
  }

  return { doc, role };
}

// Middleware factory for Express routes
export function requireDocPermission(requiredRole = 'viewer') {
  return async (req, res, next) => {
    try {
      const docId = req.params.id || req.params.documentId;
      if (!docId) {
        throw new NotFoundError('Document ID is required');
      }

      const { doc, role } = await checkDocumentAccess(docId, req.user.userId, requiredRole);
      req.doc = doc;
      req.userRole = role;
      next();
    } catch (err) {
      next(err);
    }
  };
}

