import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';
import { requireDocPermission } from '../services/permissionService.js';
import {
  listVersions,
  getVersion,
  createManualVersion,
  handleRestoreVersion,
  compareVersions,
} from '../controllers/versionController.js';

const router = Router({ mergeParams: true });

const manualVersionSchema = z.object({
  label: z.string().max(100, 'Label cannot exceed 100 characters').optional(),
});

router.use(requireAuth);

router.get('/', requireDocPermission('viewer'), listVersions);
router.get('/:version', requireDocPermission('viewer'), getVersion);
router.post('/', requireDocPermission('editor'), validate(manualVersionSchema), createManualVersion);
router.post('/:version/restore', requireDocPermission('editor'), handleRestoreVersion);
router.get('/diff/:v1/:v2', requireDocPermission('viewer'), compareVersions);

export default router;

