import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';
import { requireDocPermission } from '../services/permissionService.js';
import shareRoutes from './shareRoutes.js';
import versionRoutes from './versionRoutes.js';
import {
  createDocument,
  getDocumentById,
  getMyDocuments,
  getSharedDocuments,
  updateDocument,
  deleteDocument,
  restoreDocument,
} from '../controllers/documentController.js';

const router = Router();

const createDocSchema = z.object({
  title: z.string().max(200, 'Title cannot exceed 200 characters').optional(),
});

const updateDocSchema = z.object({
  title: z.string().min(1, 'Title cannot be empty').max(200, 'Title cannot exceed 200 characters'),
});

// All document management routes require authentication
router.use(requireAuth);

// Dashboard listing endpoints
router.get('/mine', getMyDocuments);
router.get('/shared', getSharedDocuments);

// Document CRUD
router.post('/', validate(createDocSchema), createDocument);
router.get('/:id', requireDocPermission('viewer'), getDocumentById);
router.patch('/:id', requireDocPermission('editor'), validate(updateDocSchema), updateDocument);
router.delete('/:id', requireDocPermission('owner'), deleteDocument);
router.post('/:id/restore', restoreDocument);

// Mount sharing sub-routes: /api/documents/:id/share/...
router.use('/:id/share', shareRoutes);

// Mount version history sub-routes: /api/documents/:id/versions/...
router.use('/:id/versions', versionRoutes);

export default router;
