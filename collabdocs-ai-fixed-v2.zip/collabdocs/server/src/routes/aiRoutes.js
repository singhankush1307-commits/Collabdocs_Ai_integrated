import { Router } from 'express';
import { z } from 'zod';
import rateLimit from 'express-rate-limit';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';
import { requireDocPermission } from '../services/permissionService.js';
import { transformText } from '../services/aiService.js';
import { env } from '../config/env.js';

const router = Router();

// Per-user rate limiting on AI transformation route to prevent abuse
const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: env.NODE_ENV === 'test' ? 100 : 20, // 20 requests per min
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: {
      code: 'TOO_MANY_REQUESTS',
      message: 'Too many AI requests. Please slow down and try again shortly.',
    },
  },
});

const transformSchema = z.object({
  documentId: z
    .string()
    .min(1, 'documentId is required')
    .regex(/^[a-f\d]{24}$/i, 'documentId must be a valid document ID'),
  text: z
    .string()
    .min(5, 'Text must be at least 5 characters')
    .max(5000, 'Text must not exceed 5,000 characters'),
  action: z.enum(['summarize', 'rewrite', 'fix_grammar']),
  tone: z.enum(['formal', 'concise', 'friendly']).default('formal').optional(),
});

router.post(
  '/transform',
  requireAuth,
  aiLimiter,
  validate(transformSchema),
  // Enforce Editor or higher permission on the referenced document
  async (req, res, next) => {
    req.params.id = req.body.documentId;
    return requireDocPermission('editor')(req, res, next);
  },
  async (req, res, next) => {
    try {
      const { text, action, tone = 'formal' } = req.body;
      const result = await transformText({
        text,
        action,
        tone,
        userId: req.user.userId,
        req,
      });

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (err) {
      next(err);
    }
  }
);

export default router;

