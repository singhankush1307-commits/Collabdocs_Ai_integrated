import { Router } from 'express';
import { z } from 'zod';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';
import { requireDocPermission } from '../services/permissionService.js';
import {
  inviteCollaborator,
  removeCollaborator,
  createShareLink,
  revokeShareLink,
  accessShareLink,
} from '../controllers/shareController.js';

const router = Router({ mergeParams: true });

const inviteSchema = z.object({
  email: z.string().email(),
  role: z.enum(['editor', 'commenter', 'viewer']),
});

const createLinkSchema = z.object({
  role: z.enum(['editor', 'commenter', 'viewer']).default('viewer'),
  expiresInDays: z.number().int().positive().nullable().optional(),
});

// Require user authentication for sharing operations
router.use(requireAuth);

// Routes scoped under /api/documents/:id/share
router.post('/invite', requireDocPermission('owner'), validate(inviteSchema), inviteCollaborator);
router.delete('/collaborators/:collaboratorUserId', requireDocPermission('owner'), removeCollaborator);
router.post('/links', requireDocPermission('owner'), validate(createLinkSchema), createShareLink);
router.delete('/links/:token', requireDocPermission('owner'), revokeShareLink);

// Route for redeeming a share link token: /api/share/join/:token
export const joinRouter = Router();
joinRouter.post('/join/:token', requireAuth, accessShareLink);

export default router;

