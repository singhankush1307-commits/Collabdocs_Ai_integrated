import { ZodError } from 'zod';
import { BadRequestError } from '../utils/errors.js';

export function validate(schema, source = 'body') {
  return async (req, res, next) => {
    try {
      const dataToValidate = req[source];
      const validated = await schema.parseAsync(dataToValidate);
      req[source] = validated;
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        next(err);
      } else {
        next(new BadRequestError('Invalid request data'));
      }
    }
  };
}

