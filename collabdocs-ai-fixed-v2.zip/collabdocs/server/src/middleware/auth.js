import { verifyAccessToken } from '../utils/security.js';
import { UnauthorizedError, ForbiddenError } from '../utils/errors.js';
import { env } from '../config/env.js';

export const REFRESH_COOKIE_NAME = 'collabdocs_refresh_token';

export function getCookieOptions() {
  const isProduction = env.NODE_ENV === 'production';
  return {
    httpOnly: true,
    secure: isProduction || env.COOKIE_SECURE,
    sameSite: env.COOKIE_SAME_SITE, // 'strict'
    path: '/api/auth',
    maxAge: env.JWT_REFRESH_EXPIRES_DAYS * 24 * 60 * 60 * 1000,
  };
}

export function requireAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedError('Authentication token missing or malformed');
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyAccessToken(token);

    req.user = {
      userId: decoded.userId,
      email: decoded.email,
      name: decoded.name,
    };

    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      next(new UnauthorizedError('Access token expired', { expired: true }));
    } else if (err instanceof UnauthorizedError) {
      next(err);
    } else {
      next(new UnauthorizedError('Invalid access token'));
    }
  }
}

export function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      const decoded = verifyAccessToken(token);
      req.user = {
        userId: decoded.userId,
        email: decoded.email,
        name: decoded.name,
      };
    } catch {
      // Ignored for optional auth
    }
  }
  next();
}

// CSRF Defense: Enforce custom header on sensitive state-changing cookie operations
export function verifyCsrfHeader(req, res, next) {
  const customHeader = req.headers['x-requested-with'];
  if (!customHeader || customHeader !== 'CollabDocs') {
    return next(
      new ForbiddenError('CSRF protection: missing or invalid X-Requested-With header')
    );
  }
  next();
}

