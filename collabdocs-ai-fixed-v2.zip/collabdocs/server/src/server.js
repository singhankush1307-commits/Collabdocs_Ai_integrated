import http from 'http';
import mongoose from 'mongoose';
import { createApp } from './app.js';
import { env } from './config/env.js';
import { logger } from './utils/logger.js';
import { setupSocketServer } from './socket/yjsSocketServer.js';

export async function startServer() {
  const app = createApp();
  const server = http.createServer(app);
  const io = setupSocketServer(server);

  // Connect to MongoDB
  try {
    logger.info({ uri: env.MONGODB_URI.replace(/:([^@]+)@/, ':****@') }, 'Connecting to MongoDB...');
    await mongoose.connect(env.MONGODB_URI);
    logger.info('MongoDB connected successfully');
  } catch (err) {
    logger.error(err, 'Failed to connect to MongoDB');
    process.exit(1);
  }

  // Graceful shutdown helper
  let isShuttingDown = false;
  const gracefulShutdown = async (signal) => {
    if (isShuttingDown) return;
    isShuttingDown = true;
    logger.info({ signal }, 'Graceful shutdown initiated');

    // Close Socket.io and HTTP server
    io.close(() => {
      logger.info('Socket.io server closed');
    });

    server.close(async () => {
      logger.info('HTTP server closed');
      try {
        await mongoose.connection.close(false);
        logger.info('MongoDB connection closed');
        process.exit(0);
      } catch (err) {
        logger.error(err, 'Error closing MongoDB connection');
        process.exit(1);
      }
    });

    // Force close after 10 seconds if shutdown hangs
    setTimeout(() => {
      logger.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 10000).unref();
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));

  server.listen(env.PORT, env.HOST, () => {
    logger.info(
      { port: env.PORT, host: env.HOST, env: env.NODE_ENV },
      `CollabDocs Server listening on http://${env.HOST}:${env.PORT}`
    );
  });

  return { app, server, io };
}

// Start if executed directly
if (process.argv[1] && process.argv[1].endsWith('server.js')) {
  startServer().catch((err) => {
    logger.error(err, 'Fatal error starting server');
    process.exit(1);
  });
}
