import { z } from 'zod';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env from server directory or root directory if present
dotenv.config({ path: path.resolve(__dirname, '../../.env') });
dotenv.config({ path: path.resolve(__dirname, '../../../.env') });

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().positive().default(5000),
  HOST: z.string().default('0.0.0.0'),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  CLIENT_URL: z.string().url().default('http://localhost:5173'),
  MONGODB_URI: z.string().min(1, 'MONGODB_URI is required').default('mongodb://localhost:27017/collabdocs'),
  
  // JWT & Auth Secrets (enforce >= 32 characters in production)
  JWT_ACCESS_SECRET: z.string().min(16, 'JWT_ACCESS_SECRET must be at least 16 characters').default('collabdocs_super_secret_access_jwt_key_32_chars_min!'),
  JWT_REFRESH_SECRET: z.string().min(16, 'JWT_REFRESH_SECRET must be at least 16 characters').default('collabdocs_super_secret_refresh_jwt_key_32_chars_min!'),
  JWT_ACCESS_EXPIRES_IN: z.string().default('15m'),
  JWT_REFRESH_EXPIRES_DAYS: z.coerce.number().int().positive().default(7),
  
  // Cookies
  COOKIE_SECURE: z.preprocess((val) => {
    if (typeof val === 'string') return val.toLowerCase() === 'true';
    return Boolean(val);
  }, z.boolean().default(false)),
  COOKIE_SAME_SITE: z.enum(['strict', 'lax', 'none']).default('strict'),
  
  // Rate limits
  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(15 * 60 * 1000),
  RATE_LIMIT_MAX_REQUESTS: z.coerce.number().int().positive().default(200),
  AUTH_RATE_LIMIT_MAX_REQUESTS: z.coerce.number().int().positive().default(15),
  
  // AI Provider
  AI_PROVIDER: z.enum(['mock', 'gemini', 'openai']).default('mock'),
  AI_API_KEY: z.string().optional().default(''),
  AI_MODEL_NAME: z.string().default('gemini-2.5-flash-lite'),
  AI_DAILY_QUOTA_PER_USER: z.coerce.number().int().positive().default(50),
  
  // Redis for horizontal scaling
  REDIS_ENABLED: z.preprocess((val) => {
    if (typeof val === 'string') return val.toLowerCase() === 'true';
    return Boolean(val);
  }, z.boolean().default(false)),
  REDIS_URL: z.string().default('redis://localhost:6379'),
});

export function validateEnv(rawEnv = process.env) {
  const result = envSchema.safeParse(rawEnv);
  if (!result.success) {
    const errorDetails = result.error.errors
      .map((err) => `  - ${err.path.join('.')}: ${err.message}`)
      .join('\n');
    const message = `[FATAL] Environment configuration validation failed:\n${errorDetails}`;
    // If in test and rawEnv was explicitly passed, throw directly for tests to catch
    if (process.env.NODE_ENV === 'test' && rawEnv !== process.env) {
      throw new Error(message);
    }
    // Fail fast on application startup
    console.error(message);
    process.exit(1);
  }
  return result.data;
}

export const env = validateEnv();

