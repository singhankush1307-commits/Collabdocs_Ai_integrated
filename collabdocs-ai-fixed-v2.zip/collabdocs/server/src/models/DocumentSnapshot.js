import mongoose from 'mongoose';

const documentSnapshotSchema = new mongoose.Schema(
  {
    documentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Document',
      required: true,
      index: true,
    },
    snapshot: {
      type: Buffer,
      required: true,
    },
    version: {
      type: Number,
      required: true,
    },
    label: {
      type: String,
      default: '',
      trim: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    isManual: {
      type: Boolean,
      default: false,
    },
    createdAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
  },
  {
    timestamps: false,
  }
);

// Compound index for querying snapshots per document sorted by version descending
documentSnapshotSchema.index({ documentId: 1, version: -1 });

export const DocumentSnapshot = mongoose.model('DocumentSnapshot', documentSnapshotSchema);

