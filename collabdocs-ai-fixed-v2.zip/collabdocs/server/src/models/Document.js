import mongoose from 'mongoose';

const collaboratorSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    email: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
    },
    role: {
      type: String,
      enum: ['owner', 'editor', 'commenter', 'viewer'],
      default: 'editor',
      required: true,
    },
    addedAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false }
);

const shareLinkSchema = new mongoose.Schema(
  {
    token: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      enum: ['editor', 'commenter', 'viewer'],
      default: 'viewer',
      required: true,
    },
    expiresAt: {
      type: Date,
      default: null,
    },
    isRevoked: {
      type: Boolean,
      default: false,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false }
);

const documentSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
      default: 'Untitled Document',
    },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    collaborators: [collaboratorSchema],
    shareLinks: [shareLinkSchema],
    isDeleted: {
      type: Boolean,
      default: false,
      index: true,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
    lastCompactedAt: {
      type: Date,
      default: Date.now,
    },
    currentVersion: {
      type: Number,
      default: 1,
    },
  },
  {
    timestamps: true,
  }
);

// Compound & text indexes for dashboard search, pagination, and access lookups
documentSchema.index({ title: 'text' });
documentSchema.index({ 'collaborators.user': 1 });
documentSchema.index({ 'shareLinks.token': 1 }, { sparse: true });
documentSchema.index({ updatedAt: -1 });

export const Document = mongoose.model('Document', documentSchema);
