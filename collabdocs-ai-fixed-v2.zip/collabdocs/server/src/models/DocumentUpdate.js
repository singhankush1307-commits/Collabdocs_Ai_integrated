import mongoose from 'mongoose';

const documentUpdateSchema = new mongoose.Schema(
  {
    documentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Document',
      required: true,
      index: true,
    },
    update: {
      type: Buffer,
      required: true,
    },
    origin: {
      type: String,
      default: null,
    },
    createdAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
  },
  {
    timestamps: false,
  }
);

// Compound index for querying updates for a document after a specific date
documentUpdateSchema.index({ documentId: 1, createdAt: 1 });

export const DocumentUpdate = mongoose.model('DocumentUpdate', documentUpdateSchema);

