import mongoose from 'mongoose';

const refreshTokenSchema = new mongoose.Schema(
  {
    tokenHash: { type: String, required: true },
    familyId: { type: String, required: true, index: true },
    expiresAt: { type: Date, required: true },
    isRevoked: { type: Boolean, default: false },
  },
  { timestamps: true }
);

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true,
    },
    passwordHash: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    avatarColor: {
      type: String,
      default: () => {
        const colors = [
          '#ef4444', '#f97316', '#f59e0b', '#10b981', 
          '#06b6d4', '#3b82f6', '#6366f1', '#8b5cf6', 
          '#ec4899', '#14b8a6'
        ];
        return colors[Math.floor(Math.random() * colors.length)];
      },
    },
    failedLoginAttempts: {
      type: Number,
      default: 0,
    },
    lockUntil: {
      type: Date,
      default: null,
    },
    refreshTokens: [refreshTokenSchema],
    aiUsage: {
      count: { type: Number, default: 0 },
      date: { type: String, default: () => new Date().toISOString().slice(0, 10) },
    },
  },
  {
    timestamps: true,
  }
);

// Virtual property to check if account is currently locked
userSchema.virtual('isLocked').get(function () {
  return !!(this.lockUntil && this.lockUntil > new Date());
});

export const User = mongoose.model('User', userSchema);

