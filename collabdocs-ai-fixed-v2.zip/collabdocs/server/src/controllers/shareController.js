import { Document } from '../models/Document.js';
import { User } from '../models/User.js';
import { generateSecureToken } from '../utils/security.js';
import { BadRequestError, NotFoundError, ForbiddenError } from '../utils/errors.js';
import { logSecurityEvent } from '../services/auditService.js';

// Invite collaborator by email
export async function inviteCollaborator(req, res, next) {
  try {
    const { email, role } = req.body;
    const doc = req.doc; // Provided by requireDocPermission('owner')

    const normalizedEmail = email.toLowerCase().trim();
    const userToInvite = await User.findOne({ email: normalizedEmail });

    if (!userToInvite) {
      throw new NotFoundError('No user found with that email address');
    }

    if (userToInvite._id.toString() === doc.owner.toString()) {
      throw new BadRequestError('User is already the owner of this document');
    }

    // Check if already a collaborator
    const existingIndex = doc.collaborators.findIndex(
      (c) => c.user.toString() === userToInvite._id.toString()
    );

    if (existingIndex >= 0) {
      // Update existing role
      doc.collaborators[existingIndex].role = role;
    } else {
      // Add new collaborator
      doc.collaborators.push({
        user: userToInvite._id,
        email: userToInvite.email,
        role,
        addedAt: new Date(),
      });
    }

    await doc.save();

    await logSecurityEvent({
      event: 'DOC_COLLABORATOR_UPDATED',
      userId: req.user.userId,
      targetId: doc._id.toString(),
      req,
      details: { invitedUser: userToInvite.email, role },
    });

    res.status(200).json({
      success: true,
      message: 'Collaborator added/updated successfully',
      data: {
        collaborators: doc.collaborators,
      },
    });
  } catch (err) {
    next(err);
  }
}

// Remove collaborator
export async function removeCollaborator(req, res, next) {
  try {
    const { collaboratorUserId } = req.params;
    const doc = req.doc; // Owner required

    doc.collaborators = doc.collaborators.filter(
      (c) => c.user.toString() !== collaboratorUserId
    );

    await doc.save();

    await logSecurityEvent({
      event: 'DOC_COLLABORATOR_REMOVED',
      userId: req.user.userId,
      targetId: doc._id.toString(),
      req,
      details: { removedUserId: collaboratorUserId },
    });

    res.status(200).json({
      success: true,
      message: 'Collaborator removed successfully',
      data: {
        collaborators: doc.collaborators,
      },
    });
  } catch (err) {
    next(err);
  }
}

// Create or get a share link
export async function createShareLink(req, res, next) {
  try {
    const { role = 'viewer', expiresInDays = null } = req.body;
    const doc = req.doc; // Owner required

    const token = generateSecureToken(24);
    const expiresAt = expiresInDays
      ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
      : null;

    doc.shareLinks.push({
      token,
      role,
      expiresAt,
      isRevoked: false,
      createdAt: new Date(),
    });

    await doc.save();

    await logSecurityEvent({
      event: 'DOC_SHARE_LINK_CREATED',
      userId: req.user.userId,
      targetId: doc._id.toString(),
      req,
      details: { role, expiresAt },
    });

    res.status(201).json({
      success: true,
      data: {
        token,
        role,
        expiresAt,
        shareUrl: `${process.env.CLIENT_URL || 'http://localhost:5173'}/join/${token}`,
      },
    });
  } catch (err) {
    next(err);
  }
}

// Revoke a share link
export async function revokeShareLink(req, res, next) {
  try {
    const { token } = req.params;
    const doc = req.doc; // Owner required

    const link = doc.shareLinks.find((l) => l.token === token);
    if (!link) {
      throw new NotFoundError('Share link not found');
    }

    link.isRevoked = true;
    await doc.save();

    await logSecurityEvent({
      event: 'DOC_SHARE_LINK_REVOKED',
      userId: req.user.userId,
      targetId: doc._id.toString(),
      req,
      details: { token },
    });

    res.status(200).json({
      success: true,
      message: 'Share link revoked successfully',
    });
  } catch (err) {
    next(err);
  }
}

// Access document via share link token
export async function accessShareLink(req, res, next) {
  try {
    const { token } = req.params;
    const userId = req.user.userId;

    const doc = await Document.findOne({ 'shareLinks.token': token, isDeleted: false });
    if (!doc) {
      throw new NotFoundError('Invalid share link');
    }

    const link = doc.shareLinks.find((l) => l.token === token);
    if (!link || link.isRevoked) {
      throw new ForbiddenError('This share link has been revoked');
    }

    if (link.expiresAt && link.expiresAt < new Date()) {
      throw new ForbiddenError('This share link has expired');
    }

    // If user is already owner or collaborator with equal or higher role, return doc
    const currentRole = doc.owner.toString() === userId ? 'owner' : null;
    const isCollab = doc.collaborators.some((c) => c.user.toString() === userId);

    if (!currentRole && !isCollab) {
      const user = await User.findById(userId);
      doc.collaborators.push({
        user: user._id,
        email: user.email,
        role: link.role,
        addedAt: new Date(),
      });
      await doc.save();
    }

    res.status(200).json({
      success: true,
      data: {
        documentId: doc._id.toString(),
        title: doc.title,
        role: link.role,
      },
    });
  } catch (err) {
    next(err);
  }
}

