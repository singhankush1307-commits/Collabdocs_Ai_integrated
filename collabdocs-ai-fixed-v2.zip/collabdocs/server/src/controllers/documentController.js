import { Document } from '../models/Document.js';
import { DocumentSnapshot } from '../models/DocumentSnapshot.js';
import { DocumentUpdate } from '../models/DocumentUpdate.js';
import { BadRequestError, NotFoundError } from '../utils/errors.js';
import { logSecurityEvent } from '../services/auditService.js';
import { resolveUserRole } from '../services/permissionService.js';
import { toBuffer } from '../utils/binary.js';
import * as Y from 'yjs';

// Create new document
export async function createDocument(req, res, next) {
  try {
    const { title = 'Untitled Document' } = req.body;
    const userId = req.user.userId;

    const doc = await Document.create({
      title: title.trim() || 'Untitled Document',
      owner: userId,
      collaborators: [],
      shareLinks: [],
      currentVersion: 1,
    });

    // Initialize blank Yjs document state snapshot
    const ydoc = new Y.Doc();
    const ytext = ydoc.getText('prosemirror');
    ytext.insert(0, '');
    const initialBinary = Y.encodeStateAsUpdate(ydoc);

    await DocumentSnapshot.create({
      documentId: doc._id,
      snapshot: toBuffer(initialBinary),
      version: 1,
      label: 'Initial Document Creation',
      createdBy: userId,
      isManual: false,
    });

    await logSecurityEvent({
      event: 'DOC_CREATED',
      userId,
      targetId: doc._id.toString(),
      req,
      details: { title: doc.title },
    });

    res.status(201).json({
      success: true,
      data: {
        document: {
          id: doc._id.toString(),
          title: doc.title,
          owner: doc.owner,
          role: 'owner',
          createdAt: doc.createdAt,
          updatedAt: doc.updatedAt,
        },
      },
    });
  } catch (err) {
    next(err);
  }
}

// Get document metadata and user role
export async function getDocumentById(req, res, next) {
  try {
    const doc = req.doc; // Provided by requireDocPermission
    const role = req.userRole;

    await doc.populate('owner', 'name email avatarColor');
    await doc.populate('collaborators.user', 'name email avatarColor');

    res.status(200).json({
      success: true,
      data: {
        document: {
          id: doc._id.toString(),
          title: doc.title,
          owner: doc.owner,
          collaborators: doc.collaborators,
          shareLinks: role === 'owner' ? doc.shareLinks.filter((l) => !l.isRevoked) : [],
          currentVersion: doc.currentVersion,
          createdAt: doc.createdAt,
          updatedAt: doc.updatedAt,
          role,
        },
      },
    });
  } catch (err) {
    next(err);
  }
}

// List user's own documents (with pagination and search)
export async function getMyDocuments(req, res, next) {
  try {
    const userId = req.user.userId;
    const page = Math.max(1, parseInt(req.query.page || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit || '10', 10)));
    const search = req.query.search ? req.query.search.trim() : '';

    const filter = {
      owner: userId,
      isDeleted: false,
    };

    if (search) {
      filter.title = { $regex: search, $options: 'i' };
    }

    const total = await Document.countDocuments(filter);
    const documents = await Document.find(filter)
      .sort({ updatedAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate('owner', 'name email avatarColor');

    res.status(200).json({
      success: true,
      data: {
        documents: documents.map((d) => ({
          id: d._id.toString(),
          title: d.title,
          owner: d.owner,
          collaboratorCount: d.collaborators.length,
          currentVersion: d.currentVersion,
          createdAt: d.createdAt,
          updatedAt: d.updatedAt,
          role: 'owner',
        })),
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (err) {
    next(err);
  }
}

// List documents shared with the user
export async function getSharedDocuments(req, res, next) {
  try {
    const userId = req.user.userId;
    const page = Math.max(1, parseInt(req.query.page || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit || '10', 10)));
    const search = req.query.search ? req.query.search.trim() : '';

    const filter = {
      'collaborators.user': userId,
      isDeleted: false,
    };

    if (search) {
      filter.title = { $regex: search, $options: 'i' };
    }

    const total = await Document.countDocuments(filter);
    const documents = await Document.find(filter)
      .sort({ updatedAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate('owner', 'name email avatarColor');

    res.status(200).json({
      success: true,
      data: {
        documents: documents.map((d) => ({
          id: d._id.toString(),
          title: d.title,
          owner: d.owner,
          collaboratorCount: d.collaborators.length,
          currentVersion: d.currentVersion,
          createdAt: d.createdAt,
          updatedAt: d.updatedAt,
          role: resolveUserRole(d, userId),
        })),
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (err) {
    next(err);
  }
}

// Update document title (requires editor or owner)
export async function updateDocument(req, res, next) {
  try {
    const { title } = req.body;
    const doc = req.doc;

    if (title !== undefined) {
      doc.title = title.trim() || 'Untitled Document';
    }

    await doc.save();

    res.status(200).json({
      success: true,
      data: {
        document: {
          id: doc._id.toString(),
          title: doc.title,
          updatedAt: doc.updatedAt,
        },
      },
    });
  } catch (err) {
    next(err);
  }
}

// Soft delete document (requires owner)
export async function deleteDocument(req, res, next) {
  try {
    const doc = req.doc; // Owner required
    doc.isDeleted = true;
    doc.deletedAt = new Date();
    await doc.save();

    await logSecurityEvent({
      event: 'DOC_SOFT_DELETED',
      userId: req.user.userId,
      targetId: doc._id.toString(),
      req,
      details: { title: doc.title },
    });

    res.status(200).json({
      success: true,
      message: 'Document deleted successfully',
    });
  } catch (err) {
    next(err);
  }
}

// Restore soft-deleted document (requires owner)
export async function restoreDocument(req, res, next) {
  try {
    const docId = req.params.id;
    const doc = await Document.findOne({ _id: docId, owner: req.user.userId });
    if (!doc) {
      throw new NotFoundError('Document not found or you are not the owner');
    }

    doc.isDeleted = false;
    doc.deletedAt = null;
    await doc.save();

    await logSecurityEvent({
      event: 'DOC_RESTORED',
      userId: req.user.userId,
      targetId: doc._id.toString(),
      req,
    });

    res.status(200).json({
      success: true,
      message: 'Document restored successfully',
      data: {
        document: {
          id: doc._id.toString(),
          title: doc.title,
        },
      },
    });
  } catch (err) {
    next(err);
  }
}
