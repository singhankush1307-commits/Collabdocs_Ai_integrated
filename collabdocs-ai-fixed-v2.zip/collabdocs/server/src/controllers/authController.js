import {
  registerUser,
  loginUser,
  refreshAccessToken,
  logoutUser,
  logoutAllDevices,
} from '../services/authService.js';
import { User } from '../models/User.js';
import { getCookieOptions, REFRESH_COOKIE_NAME } from '../middleware/auth.js';
import { NotFoundError } from '../utils/errors.js';

export async function register(req, res, next) {
  try {
    const { email, password, name } = req.body;
    const { user, accessToken, refreshToken } = await registerUser(
      { email, password, name },
      req
    );

    res.cookie(REFRESH_COOKIE_NAME, refreshToken, getCookieOptions());

    res.status(201).json({
      success: true,
      data: {
        user,
        accessToken,
      },
    });
  } catch (err) {
    next(err);
  }
}

export async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const { user, accessToken, refreshToken } = await loginUser({ email, password }, req);

    res.cookie(REFRESH_COOKIE_NAME, refreshToken, getCookieOptions());

    res.status(200).json({
      success: true,
      data: {
        user,
        accessToken,
      },
    });
  } catch (err) {
    next(err);
  }
}

export async function refresh(req, res, next) {
  try {
    const rawRefreshToken = req.cookies[REFRESH_COOKIE_NAME] || req.body?.refreshToken;
    const { accessToken, refreshToken: newRefreshToken, user } = await refreshAccessToken(
      rawRefreshToken,
      req
    );

    res.cookie(REFRESH_COOKIE_NAME, newRefreshToken, getCookieOptions());

    res.status(200).json({
      success: true,
      data: {
        accessToken,
        user,
      },
    });
  } catch (err) {
    next(err);
  }
}

export async function logout(req, res, next) {
  try {
    const rawRefreshToken = req.cookies[REFRESH_COOKIE_NAME] || req.body?.refreshToken;
    await logoutUser(rawRefreshToken, req);

    const { maxAge: _unused, ...clearOptions } = getCookieOptions();
    res.clearCookie(REFRESH_COOKIE_NAME, clearOptions);

    res.status(200).json({
      success: true,
      message: 'Logged out successfully',
    });
  } catch (err) {
    next(err);
  }
}

export async function logoutAll(req, res, next) {
  try {
    await logoutAllDevices(req.user.userId, req);

    const { maxAge: _unused, ...clearOptions } = getCookieOptions();
    res.clearCookie(REFRESH_COOKIE_NAME, clearOptions);

    res.status(200).json({
      success: true,
      message: 'Logged out from all devices',
    });
  } catch (err) {
    next(err);
  }
}

export async function getMe(req, res, next) {
  try {
    const user = await User.findById(req.user.userId).select('-passwordHash -refreshTokens');
    if (!user) {
      throw new NotFoundError('User not found');
    }

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user._id.toString(),
          email: user.email,
          name: user.name,
          avatarColor: user.avatarColor,
        },
      },
    });
  } catch (err) {
    next(err);
  }
}
