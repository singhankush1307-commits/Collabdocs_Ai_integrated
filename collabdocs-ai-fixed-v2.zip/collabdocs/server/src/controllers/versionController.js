import {
  getVersionList,
  getVersionContent,
  compactDocument,
  restoreVersion,
} from '../services/yjsPersistenceService.js';
import * as Y from 'yjs';
import { DocumentSnapshot } from '../models/DocumentSnapshot.js';
import { NotFoundError } from '../utils/errors.js';

// List versions
export async function listVersions(req, res, next) {
  try {
    const documentId = req.params.id;
    const versions = await getVersionList(documentId);
    res.status(200).json({
      success: true,
      data: {
        versions,
      },
    });
  } catch (err) {
    next(err);
  }
}

// Get single version details / preview
export async function getVersion(req, res, next) {
  try {
    const documentId = req.params.id;
    const versionNumber = parseInt(req.params.version, 10);
    const content = await getVersionContent(documentId, versionNumber);

    res.status(200).json({
      success: true,
      data: {
        version: content,
      },
    });
  } catch (err) {
    next(err);
  }
}

// Manual Save Version
export async function createManualVersion(req, res, next) {
  try {
    const documentId = req.params.id;
    const { label = '' } = req.body;
    const userId = req.user.userId;

    const snapshot = await compactDocument(documentId, label, userId, true);

    res.status(201).json({
      success: true,
      message: 'Version saved successfully',
      data: {
        version: {
          id: snapshot._id.toString(),
          version: snapshot.version,
          label: snapshot.label,
          createdAt: snapshot.createdAt,
        },
      },
    });
  } catch (err) {
    next(err);
  }
}

// Restore Version
export async function handleRestoreVersion(req, res, next) {
  try {
    const documentId = req.params.id;
    const versionNumber = parseInt(req.params.version, 10);
    const userId = req.user.userId;

    const newSnapshot = await restoreVersion(documentId, versionNumber, userId, req);

    res.status(200).json({
      success: true,
      message: `Restored successfully from version ${versionNumber}`,
      data: {
        version: {
          version: newSnapshot.version,
          label: newSnapshot.label,
          createdAt: newSnapshot.createdAt,
        },
      },
    });
  } catch (err) {
    next(err);
  }
}

// Compare two versions
export async function compareVersions(req, res, next) {
  try {
    const documentId = req.params.id;
    const v1 = parseInt(req.params.v1, 10);
    const v2 = parseInt(req.params.v2, 10);

    const s1 = await DocumentSnapshot.findOne({ documentId, version: v1 });
    const s2 = await DocumentSnapshot.findOne({ documentId, version: v2 });

    if (!s1 || !s2) {
      throw new NotFoundError('One or both versions were not found');
    }

    const doc1 = new Y.Doc();
    const doc2 = new Y.Doc();
    Y.applyUpdate(doc1, new Uint8Array(s1.snapshot));
    Y.applyUpdate(doc2, new Uint8Array(s2.snapshot));

    const text1 = doc1.getText('prosemirror').toString();
    const text2 = doc2.getText('prosemirror').toString();

    res.status(200).json({
      success: true,
      data: {
        v1: { version: v1, label: s1.label, text: text1 },
        v2: { version: v2, label: s2.label, text: text2 },
      },
    });
  } catch (err) {
    next(err);
  }
}

