import { Server } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { createClient } from 'redis';
import * as Y from 'yjs';
import * as syncProtocol from 'y-protocols/sync';
import * as awarenessProtocol from 'y-protocols/awareness';
import * as encoding from 'lib0/encoding';
import * as decoding from 'lib0/decoding';
import { verifyAccessToken } from '../utils/security.js';
import { User } from '../models/User.js';
import { Document } from '../models/Document.js';
import { resolveUserRole } from '../services/permissionService.js';
import { toUint8Array, toBuffer } from '../utils/binary.js';
import {
  getOrLoadDoc,
  persistUpdate,
  flushAndEvictDoc,
} from '../services/yjsPersistenceService.js';
import { logSecurityEvent } from '../services/auditService.js';
import { logger } from '../utils/logger.js';
import { env } from '../config/env.js';

const MAX_PAYLOAD_BYTES = 100 * 1024; // 100 KB max update payload
const RATE_LIMIT_WINDOW_MS = 1000;
const MAX_UPDATES_PER_SEC = 60; // Max 60 sync updates/sec per socket

export function setupSocketServer(httpServer) {
  const io = new Server(httpServer, {
    cors: {
      origin: [env.CLIENT_URL, 'http://localhost:5173', 'http://127.0.0.1:5173'],
      credentials: true,
    },
    maxHttpBufferSize: MAX_PAYLOAD_BYTES,
    pingTimeout: 30000,
    pingInterval: 15000,
  });

  // Optional horizontal scalability via Redis adapter
  if (env.REDIS_ENABLED) {
    try {
      const pubClient = createClient({ url: env.REDIS_URL });
      const subClient = pubClient.duplicate();
      Promise.all([pubClient.connect(), subClient.connect()]).then(() => {
        io.adapter(createAdapter(pubClient, subClient));
        logger.info({ redisUrl: env.REDIS_URL }, 'Socket.io Redis adapter connected for horizontal scaling');
      }).catch((err) => {
        logger.error(err, 'Failed to connect Redis adapter, falling back to in-memory adapter');
      });
    } catch (err) {
      logger.error(err, 'Redis adapter initialization error');
    }
  }

  // Socket Authentication Middleware
  io.use(async (socket, next) => {
    try {
      const token =
        socket.handshake.auth?.token ||
        socket.handshake.headers?.authorization?.replace('Bearer ', '');

      if (!token) {
        return next(new Error('Authentication token required'));
      }

      const decoded = verifyAccessToken(token);
      const user = await User.findById(decoded.userId).select('name email avatarColor');

      if (!user) {
        return next(new Error('User not found'));
      }

      socket.user = {
        userId: user._id.toString(),
        name: user.name,
        email: user.email,
        avatarColor: user.avatarColor,
      };

      socket.docRoles = new Map(); // docId -> role
      socket.rateTracker = { count: 0, windowStart: Date.now() };

      next();
    } catch (err) {
      logger.warn({ err: err.message }, 'Socket connection authentication failed');
      return next(new Error('Invalid or expired authentication token'));
    }
  });

  // Track active users per room: docId -> Map(socketId, userInfo)
  const roomPresences = new Map();

  function broadcastPresence(docId) {
    const presences = roomPresences.get(docId);
    if (!presences) return;

    // Deduplicate users in the room
    const userMap = new Map();
    for (const [_, info] of presences.entries()) {
      userMap.set(info.userId, info);
    }

    const activeUsers = Array.from(userMap.values());
    io.to(`document:${docId}`).emit('room-presence', {
      documentId: docId,
      activeUsers,
    });
  }

  io.on('connection', (socket) => {
    logger.info({ userId: socket.user.userId, socketId: socket.id }, 'Socket connected');

    // 1. Join Document Room
    socket.on('join-document', async ({ documentId }, ack) => {
      try {
        if (!documentId) {
          if (typeof ack === 'function') ack({ success: false, error: 'Document ID is required' });
          return;
        }

        const docRecord = await Document.findOne({ _id: documentId, isDeleted: false });
        if (!docRecord) {
          if (typeof ack === 'function') ack({ success: false, error: 'Document not found' });
          return;
        }

        const role = resolveUserRole(docRecord, socket.user.userId);
        if (!role) {
          await logSecurityEvent({
            event: 'SOCKET_UNAUTHORIZED_JOIN_ATTEMPT',
            userId: socket.user.userId,
            targetId: documentId,
            details: { email: socket.user.email },
          });

          if (typeof ack === 'function') ack({ success: false, error: 'Access denied' });
          return;
        }

        // Cache role for this document
        socket.docRoles.set(documentId.toString(), role);
        const roomName = `document:${documentId}`;
        socket.join(roomName);

        // Track presence
        if (!roomPresences.has(documentId)) {
          roomPresences.set(documentId, new Map());
        }
        roomPresences.get(documentId).set(socket.id, {
          userId: socket.user.userId,
          name: socket.user.name,
          email: socket.user.email,
          avatarColor: socket.user.avatarColor,
          role,
        });

        broadcastPresence(documentId);

        // Load document state and send Sync Step 1 to newly joined client
        const { ydoc } = await getOrLoadDoc(documentId);

        const encoder = encoding.createEncoder();
        encoding.writeVarUint(encoder, 0); // messageSync = 0
        syncProtocol.writeSyncStep1(encoder, ydoc);
        const syncMessage = encoding.toUint8Array(encoder);

        socket.emit('sync-message', {
          documentId,
          payload: Buffer.from(syncMessage),
        });

        if (typeof ack === 'function') {
          ack({
            success: true,
            data: {
              documentId,
              role,
              title: docRecord.title,
            },
          });
        }

        logger.info(
          { userId: socket.user.userId, documentId, role },
          'User joined collaborative document room'
        );
      } catch (err) {
        logger.error({ err, documentId }, 'Error joining document room');
        if (typeof ack === 'function') ack({ success: false, error: 'Internal server error' });
      }
    });

    // 2. Yjs Sync Protocol Handling
    socket.on('sync-message', async ({ documentId, payload }) => {
      try {
        if (!documentId || !payload) return;

        const role = socket.docRoles.get(documentId.toString());
        if (!role) return;

        // Rate limiting check per socket
        const now = Date.now();
        if (now - socket.rateTracker.windowStart > RATE_LIMIT_WINDOW_MS) {
          socket.rateTracker.count = 0;
          socket.rateTracker.windowStart = now;
        }
        socket.rateTracker.count += 1;

        if (socket.rateTracker.count > MAX_UPDATES_PER_SEC) {
          logger.warn(
            { userId: socket.user.userId, socketId: socket.id },
            'Rate limit exceeded for socket updates. Disconnecting abusive client.'
          );
          socket.emit('error', 'Rate limit exceeded');
          socket.disconnect(true);
          return;
        }

        const uint8Payload = toUint8Array(payload);
        if (uint8Payload.byteLength > MAX_PAYLOAD_BYTES) {
          logger.warn({ bytes: uint8Payload.byteLength }, 'Message payload exceeds max limit');
          return;
        }

        const { ydoc } = await getOrLoadDoc(documentId);
        const decoder = decoding.createDecoder(uint8Payload);
        const encoder = encoding.createEncoder();
        const messageType = decoding.readVarUint(decoder);

        if (messageType === 0) {
          // Sync protocol message
          const syncType = decoding.readVarUint(decoder);

          if (syncType === 0) {
            // Client SyncStep1 (client sent its state vector)
            // Server answers with SyncStep2 containing missing updates
            encoding.writeVarUint(encoder, 0); // messageSync = 0
            syncProtocol.writeSyncStep2(encoder, ydoc, decoding.readVarUint8Array(decoder));

            const response = encoding.toUint8Array(encoder);
            socket.emit('sync-message', {
              documentId,
              payload: toBuffer(response),
            });
          } else if (syncType === 1 || syncType === 2) {
            // SyncStep2 or Update
            // SECURITY CHECK: Verify user has write permissions (editor or owner)
            if (role === 'viewer') {
              logger.warn(
                { userId: socket.user.userId, documentId, role },
                'Security Violation: Viewer attempted to submit write updates to document. Rejected.'
              );

              await logSecurityEvent({
                event: 'DOC_UNAUTHORIZED_WRITE_REJECTED',
                userId: socket.user.userId,
                targetId: documentId,
                details: { attemptedRole: role },
              });

              socket.emit('permission-error', {
                documentId,
                code: 'FORBIDDEN',
                message: 'Viewers have read-only access and cannot edit this document.',
              });
              return;
            }

            // Valid editor/owner: read update and apply
            const update = decoding.readVarUint8Array(decoder);
            await persistUpdate(documentId, toBuffer(update), socket.id);

            // Broadcast incremental update to all other collaborators in the room
            const updateEncoder = encoding.createEncoder();
            encoding.writeVarUint(updateEncoder, 0);
            syncProtocol.writeUpdate(updateEncoder, update);
            const updateMessage = toBuffer(encoding.toUint8Array(updateEncoder));

            socket.to(`document:${documentId}`).emit('sync-message', {
              documentId,
              payload: updateMessage,
            });
          }
        }
      } catch (err) {
        logger.error({ err, documentId }, 'Error processing sync message');
      }
    });

    // 3. Awareness Protocol Handling (Live cursors & selections)
    socket.on('awareness-update', ({ documentId, payload }) => {
      if (!documentId || !payload) return;
      const role = socket.docRoles.get(documentId.toString());
      if (!role) return;

      const uint8Payload = toUint8Array(payload);
      if (uint8Payload.byteLength > MAX_PAYLOAD_BYTES) return;

      // Broadcast awareness update to room peers
      socket.to(`document:${documentId}`).emit('awareness-update', {
        documentId,
        payload: toBuffer(uint8Payload),
      });
    });

    // 4. Leave Document
    socket.on('leave-document', async ({ documentId }) => {
      if (!documentId) return;
      socket.leave(`document:${documentId}`);
      socket.docRoles.delete(documentId.toString());

      if (roomPresences.has(documentId)) {
        roomPresences.get(documentId).delete(socket.id);
        if (roomPresences.get(documentId).size === 0) {
          roomPresences.delete(documentId);
          await flushAndEvictDoc(documentId);
        } else {
          broadcastPresence(documentId);
        }
      }
    });

    // 5. Disconnect Cleanup
    socket.on('disconnect', async () => {
      logger.info({ userId: socket.user?.userId, socketId: socket.id }, 'Socket disconnected');

      for (const [docId, _] of socket.docRoles.entries()) {
        if (roomPresences.has(docId)) {
          roomPresences.get(docId).delete(socket.id);
          if (roomPresences.get(docId).size === 0) {
            roomPresences.delete(docId);
            await flushAndEvictDoc(docId);
          } else {
            broadcastPresence(docId);
          }
        }
      }

      socket.docRoles.clear();
    });
  });

  return io;
}
