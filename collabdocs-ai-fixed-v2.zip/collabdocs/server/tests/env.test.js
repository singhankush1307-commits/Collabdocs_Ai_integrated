import { describe, it, expect } from 'vitest';
import { validateEnv } from '../src/config/env.js';

describe('Phase 1: Environment Configuration Validation', () => {
  it('validates and supplies defaults for valid environment', () => {
    const rawEnv = {
      NODE_ENV: 'test',
      MONGODB_URI: 'mongodb://localhost:27017/test_db',
      JWT_ACCESS_SECRET: 'test_access_secret_long_enough_32_characters_12345',
      JWT_REFRESH_SECRET: 'test_refresh_secret_long_enough_32_characters_12345',
    };

    const config = validateEnv(rawEnv);
    expect(config.NODE_ENV).toBe('test');
    expect(config.PORT).toBe(5000);
    expect(config.JWT_ACCESS_EXPIRES_IN).toBe('15m');
    expect(config.JWT_REFRESH_EXPIRES_DAYS).toBe(7);
  });

  it('fails fast when JWT secrets are too short', () => {
    const rawEnv = {
      NODE_ENV: 'test',
      JWT_ACCESS_SECRET: 'short',
      JWT_REFRESH_SECRET: 'short',
    };

    expect(() => validateEnv(rawEnv)).toThrow(/Environment configuration validation failed/);
  });

  it('coerces numerical and boolean environment variables properly', () => {
    const rawEnv = {
      NODE_ENV: 'test',
      PORT: '8080',
      COOKIE_SECURE: 'true',
      REDIS_ENABLED: 'true',
      AI_DAILY_QUOTA_PER_USER: '100',
      JWT_ACCESS_SECRET: 'test_access_secret_long_enough_32_characters_12345',
      JWT_REFRESH_SECRET: 'test_refresh_secret_long_enough_32_characters_12345',
    };

    const config = validateEnv(rawEnv);
    expect(config.PORT).toBe(8080);
    expect(config.COOKIE_SECURE).toBe(true);
    expect(config.REDIS_ENABLED).toBe(true);
    expect(config.AI_DAILY_QUOTA_PER_USER).toBe(100);
  });
});

