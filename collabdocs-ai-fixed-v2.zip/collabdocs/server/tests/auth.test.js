import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import './setup.js';
import { REFRESH_COOKIE_NAME } from '../src/middleware/auth.js';
import { User } from '../src/models/User.js';

describe('Phase 2: Authentication and Authorization', () => {
  const app = createApp();

  const validUser = {
    name: 'Alice Developer',
    email: 'alice@example.com',
    password: 'Password123!@#',
  };

  it('registers a new user with valid credentials and enforces password policy', async () => {
    // Attempt with weak password
    const weakRes = await request(app).post('/api/auth/register').send({
      name: 'Bob',
      email: 'bob@example.com',
      password: 'password', // Missing uppercase, number, symbol
    });
    expect(weakRes.status).toBe(400);
    expect(weakRes.body.success).toBe(false);

    // Register with strong password
    const res = await request(app).post('/api/auth/register').send(validUser);
    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.user.email).toBe(validUser.email.toLowerCase());
    expect(res.body.data.user).toHaveProperty('avatarColor');
    expect(res.body.data).toHaveProperty('accessToken');

    // Verify httpOnly cookie is set
    const cookies = res.headers['set-cookie'];
    expect(cookies).toBeDefined();
    expect(cookies[0]).toContain(REFRESH_COOKIE_NAME);
    expect(cookies[0]).toContain('HttpOnly');
    expect(cookies[0]).toContain('SameSite=Strict');
  });

  it('prevents duplicate email registration', async () => {
    await request(app).post('/api/auth/register').send(validUser);
    const dupRes = await request(app).post('/api/auth/register').send(validUser);
    expect(dupRes.status).toBe(409);
    expect(dupRes.body.success).toBe(false);
  });

  it('authenticates user and returns access token on valid login', async () => {
    await request(app).post('/api/auth/register').send(validUser);

    const loginRes = await request(app).post('/api/auth/login').send({
      email: validUser.email,
      password: validUser.password,
    });

    expect(loginRes.status).toBe(200);
    expect(loginRes.body.success).toBe(true);
    expect(loginRes.body.data).toHaveProperty('accessToken');
    expect(loginRes.body.data.user.email).toBe(validUser.email);
  });

  it('returns generic error on invalid password and locks account after 5 attempts', async () => {
    await request(app).post('/api/auth/register').send(validUser);

    // 4 failed attempts
    for (let i = 0; i < 4; i++) {
      const failRes = await request(app).post('/api/auth/login').send({
        email: validUser.email,
        password: 'WrongPassword123!',
      });
      expect(failRes.status).toBe(401);
      expect(failRes.body.error.message).toBe('Invalid email or password');
    }

    // 5th failed attempt triggers lockout
    const lockRes = await request(app).post('/api/auth/login').send({
      email: validUser.email,
      password: 'WrongPassword123!',
    });
    expect(lockRes.status).toBe(429);
    expect(lockRes.body.error.message).toContain('Account is locked');

    // 6th attempt is blocked immediately due to lockout
    const blockedRes = await request(app).post('/api/auth/login').send({
      email: validUser.email,
      password: validUser.password, // even correct password blocked during lockout
    });
    expect(blockedRes.status).toBe(429);
    expect(blockedRes.body.error.message).toContain('Account is temporarily locked');
  });

  it('enforces CSRF custom header on refresh endpoint', async () => {
    const regRes = await request(app).post('/api/auth/register').send(validUser);
    const cookie = regRes.headers['set-cookie'][0];

    // Attempt refresh without X-Requested-With header
    const noHeaderRes = await request(app)
      .post('/api/auth/refresh')
      .set('Cookie', cookie);
    expect(noHeaderRes.status).toBe(403);
    expect(noHeaderRes.body.error.message).toContain('CSRF protection');

    // Refresh with valid header
    const validHeaderRes = await request(app)
      .post('/api/auth/refresh')
      .set('X-Requested-With', 'CollabDocs')
      .set('Cookie', cookie);
    expect(validHeaderRes.status).toBe(200);
    expect(validHeaderRes.body.data).toHaveProperty('accessToken');
  });

  it('rotates refresh token and revokes entire family on token reuse', async () => {
    const regRes = await request(app).post('/api/auth/register').send(validUser);
    const initialCookie = regRes.headers['set-cookie'][0];

    // First rotation: valid
    const refresh1 = await request(app)
      .post('/api/auth/refresh')
      .set('X-Requested-With', 'CollabDocs')
      .set('Cookie', initialCookie);

    expect(refresh1.status).toBe(200);
    const rotatedCookie = refresh1.headers['set-cookie'][0];
    expect(rotatedCookie).not.toEqual(initialCookie);

    // Reuse detection: try using the initial (now invalidated) cookie again!
    const reuseAttackRes = await request(app)
      .post('/api/auth/refresh')
      .set('X-Requested-With', 'CollabDocs')
      .set('Cookie', initialCookie);

    expect(reuseAttackRes.status).toBe(401);
    expect(reuseAttackRes.body.error.message).toContain('token reuse detected');

    // Verify that the entire family was revoked: rotatedCookie should also now be revoked!
    const subsequentRes = await request(app)
      .post('/api/auth/refresh')
      .set('X-Requested-With', 'CollabDocs')
      .set('Cookie', rotatedCookie);

    expect(subsequentRes.status).toBe(401);
  });

  it('supports logout and revokes the session', async () => {
    const regRes = await request(app).post('/api/auth/register').send(validUser);
    const cookie = regRes.headers['set-cookie'][0];

    const logoutRes = await request(app)
      .post('/api/auth/logout')
      .set('X-Requested-With', 'CollabDocs')
      .set('Cookie', cookie);

    expect(logoutRes.status).toBe(200);

    // Attempt refresh after logout fails
    const refreshRes = await request(app)
      .post('/api/auth/refresh')
      .set('X-Requested-With', 'CollabDocs')
      .set('Cookie', cookie);

    expect(refreshRes.status).toBe(401);
  });
});
