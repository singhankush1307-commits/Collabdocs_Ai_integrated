import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import http from 'http';
import { io as ClientSocket } from 'socket.io-client';
import * as Y from 'yjs';
import * as syncProtocol from 'y-protocols/sync';
import * as encoding from 'lib0/encoding';
import * as decoding from 'lib0/decoding';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { setupSocketServer } from '../src/socket/yjsSocketServer.js';
import './setup.js';
import { compactDocument } from '../src/services/yjsPersistenceService.js';
import { DocumentSnapshot } from '../src/models/DocumentSnapshot.js';
import { toUint8Array } from '../src/utils/binary.js';

describe('Phase 4 & 5: Real-time Collaboration (CRDT / Socket.io) & Persistence', () => {
  let app;
  let server;
  let io;
  let serverPort;

  let ownerToken;
  let editorToken;
  let viewerToken;
  let docId;
  const openSockets = [];

  beforeAll(async () => {
    app = createApp();
    server = http.createServer(app);
    io = setupSocketServer(server);

    await new Promise((resolve) => {
      server.listen(0, '127.0.0.1', () => {
        serverPort = server.address().port;
        resolve();
      });
    });
  });

  afterAll(async () => {
    for (const socket of openSockets) {
      if (socket.connected) socket.disconnect();
    }
    io.close();
    await new Promise((resolve) => server.close(resolve));
  });

  beforeEach(async () => {
    // Fresh setup before each test because setup.js cleans DB in beforeEach
    const ownerRes = await request(app).post('/api/auth/register').send({
      name: 'Owner Alice',
      email: `owner_${Date.now()}_${Math.random()}@example.com`,
      password: 'Password123!@#',
    });
    ownerToken = ownerRes.body.data.accessToken;

    const editorRes = await request(app).post('/api/auth/register').send({
      name: 'Editor Bob',
      email: `editor_${Date.now()}_${Math.random()}@example.com`,
      password: 'Password123!@#',
    });
    editorToken = editorRes.body.data.accessToken;

    const viewerRes = await request(app).post('/api/auth/register').send({
      name: 'Viewer Charlie',
      email: `viewer_${Date.now()}_${Math.random()}@example.com`,
      password: 'Password123!@#',
    });
    viewerToken = viewerRes.body.data.accessToken;

    const docRes = await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({ title: 'CRDT Concurrent Test Document' });
    docId = docRes.body.data.document.id;

    // Invite Bob as editor
    await request(app)
      .post(`/api/documents/${docId}/share/invite`)
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({ email: editorRes.body.data.user.email, role: 'editor' });

    // Invite Charlie as viewer
    await request(app)
      .post(`/api/documents/${docId}/share/invite`)
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({ email: viewerRes.body.data.user.email, role: 'viewer' });
  });

  function createClient(token) {
    const s = ClientSocket(`http://127.0.0.1:${serverPort}`, {
      auth: { token },
      transports: ['websocket'],
      forceNew: true,
      reconnection: false,
    });
    openSockets.push(s);
    return s;
  }

  it('rejects socket connection without valid JWT', async () => {
    const unauthClient = ClientSocket(`http://127.0.0.1:${serverPort}`, {
      auth: { token: 'invalid.jwt.token' },
      transports: ['websocket'],
      forceNew: true,
      reconnection: false,
    });
    openSockets.push(unauthClient);

    const errorPromise = new Promise((resolve) => {
      unauthClient.on('connect_error', (err) => {
        resolve(err.message);
      });
    });

    const errorMsg = await errorPromise;
    expect(errorMsg).toContain('Invalid or expired authentication token');
    unauthClient.close();
  });

  it('connects authenticated socket and completes sync handshake', async () => {
    const client = createClient(ownerToken);

    await new Promise((resolve) => client.on('connect', resolve));
    expect(client.connected).toBe(true);

    const ack = await new Promise((resolve) => {
      client.emit('join-document', { documentId: docId }, (response) => {
        resolve(response);
      });
    });

    expect(ack.success).toBe(true);
    expect(ack.data.role).toBe('owner');
    client.close();
  });

  it('converges concurrent edits from two clients to identical content', async () => {
    const clientA = createClient(ownerToken);
    const clientB = createClient(editorToken);

    const docA = new Y.Doc();
    const docB = new Y.Doc();

    await Promise.all([
      new Promise((res) => clientA.on('connect', res)),
      new Promise((res) => clientB.on('connect', res)),
    ]);

    // Join room
    await Promise.all([
      new Promise((res) => clientA.emit('join-document', { documentId: docId }, res)),
      new Promise((res) => clientB.emit('join-document', { documentId: docId }, res)),
    ]);

    // Handle incoming sync messages with origin 'remote' to avoid infinite echoes
    clientA.on('sync-message', ({ payload }) => {
      const decoder = decoding.createDecoder(toUint8Array(payload));
      const messageType = decoding.readVarUint(decoder);
      if (messageType === 0) {
        syncProtocol.readSyncMessage(decoder, encoding.createEncoder(), docA, 'remote');
      }
    });

    clientB.on('sync-message', ({ payload }) => {
      const decoder = decoding.createDecoder(toUint8Array(payload));
      const messageType = decoding.readVarUint(decoder);
      if (messageType === 0) {
        syncProtocol.readSyncMessage(decoder, encoding.createEncoder(), docB, 'remote');
      }
    });

    // Client A sends local updates only
    const textA = docA.getText('prosemirror');
    docA.on('update', (update, origin) => {
      if (origin === 'remote') return;
      const encoder = encoding.createEncoder();
      encoding.writeVarUint(encoder, 0); // messageSync
      syncProtocol.writeUpdate(encoder, update);
      clientA.emit('sync-message', {
        documentId: docId,
        payload: Buffer.from(encoding.toUint8Array(encoder)),
      });
    });

    // Client B sends local updates only
    const textB = docB.getText('prosemirror');
    docB.on('update', (update, origin) => {
      if (origin === 'remote') return;
      const encoder = encoding.createEncoder();
      encoding.writeVarUint(encoder, 0);
      syncProtocol.writeUpdate(encoder, update);
      clientB.emit('sync-message', {
        documentId: docId,
        payload: Buffer.from(encoding.toUint8Array(encoder)),
      });
    });

    textA.insert(0, 'Hello ');
    textB.insert(0, 'World!');

    // Wait 300ms for CRDT propagation
    await new Promise((res) => setTimeout(res, 300));

    // Both documents must converge to the same text
    expect(textA.toString()).toEqual(textB.toString());
    expect(textA.toString().length).toBeGreaterThanOrEqual(11);

    clientA.close();
    clientB.close();
  });

  it('rejects updates submitted by viewers and raises permission error', async () => {
    const viewerClient = createClient(viewerToken);
    await new Promise((res) => viewerClient.on('connect', res));

    await new Promise((res) =>
      viewerClient.emit('join-document', { documentId: docId }, res)
    );

    const permErrorPromise = new Promise((resolve) => {
      viewerClient.on('permission-error', (err) => {
        resolve(err);
      });
    });

    // Viewer generates update trying to inject text
    const maliciousDoc = new Y.Doc();
    maliciousDoc.getText('prosemirror').insert(0, 'Defaced by viewer');
    const update = Y.encodeStateAsUpdate(maliciousDoc);

    const encoder = encoding.createEncoder();
    encoding.writeVarUint(encoder, 0);
    syncProtocol.writeUpdate(encoder, update);

    viewerClient.emit('sync-message', {
      documentId: docId,
      payload: Buffer.from(encoding.toUint8Array(encoder)),
    });

    const errorResponse = await permErrorPromise;
    expect(errorResponse.code).toBe('FORBIDDEN');
    expect(errorResponse.message).toContain('Viewers have read-only access');

    viewerClient.close();
  });

  it('compacts document into snapshot and restores historical version without losing history', async () => {
    // 1. Manually compact version 2
    const snapshotV2 = await compactDocument(docId, 'Milestone 1', null, true);
    expect(snapshotV2.version).toBe(2);
    expect(snapshotV2.label).toBe('Milestone 1');

    // 2. Fetch version history via REST
    const listRes = await request(app)
      .get(`/api/documents/${docId}/versions`)
      .set('Authorization', `Bearer ${ownerToken}`);

    expect(listRes.status).toBe(200);
    expect(listRes.body.data.versions.length).toBeGreaterThanOrEqual(2);

    // 3. Restore version 1
    const restoreRes = await request(app)
      .post(`/api/documents/${docId}/versions/1/restore`)
      .set('Authorization', `Bearer ${ownerToken}`);

    expect(restoreRes.status).toBe(200);
    expect(restoreRes.body.data.version.version).toBe(3);
    expect(restoreRes.body.data.version.label).toBe('Restored from Version 1');

    // History is preserved: total snapshots is now 3
    const finalSnapshots = await DocumentSnapshot.find({ documentId: docId });
    expect(finalSnapshots).toHaveLength(3);
  });
});
