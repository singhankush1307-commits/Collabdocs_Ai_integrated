import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import './setup.js';
import { DocumentSnapshot } from '../src/models/DocumentSnapshot.js';

describe('Phase 3: Document Management (REST API)', () => {
  const app = createApp();

  let aliceToken;
  let bobToken;
  let charlieToken;
  let bobEmail = 'bob@example.com';
  let charlieEmail = 'charlie@example.com';

  beforeEach(async () => {
    // Register Alice (Owner)
    const aliceRes = await request(app).post('/api/auth/register').send({
      name: 'Alice Owner',
      email: 'alice@example.com',
      password: 'Password123!@#',
    });
    aliceToken = aliceRes.body.data.accessToken;

    // Register Bob (Collaborator)
    const bobRes = await request(app).post('/api/auth/register').send({
      name: 'Bob Collab',
      email: bobEmail,
      password: 'Password123!@#',
    });
    bobToken = bobRes.body.data.accessToken;

    // Register Charlie (Viewer / External)
    const charlieRes = await request(app).post('/api/auth/register').send({
      name: 'Charlie External',
      email: charlieEmail,
      password: 'Password123!@#',
    });
    charlieToken = charlieRes.body.data.accessToken;
  });

  it('creates a new document with an initial Yjs binary snapshot', async () => {
    const res = await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ title: 'System Design Spec' });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.document.title).toBe('System Design Spec');
    expect(res.body.data.document.role).toBe('owner');

    const docId = res.body.data.document.id;
    const snapshots = await DocumentSnapshot.find({ documentId: docId });
    expect(snapshots).toHaveLength(1);
    expect(snapshots[0].version).toBe(1);
    expect(snapshots[0].snapshot).toBeDefined();
  });

  it('enforces RBAC: Editors can rename, Viewers cannot', async () => {
    // Alice creates doc
    const createRes = await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ title: 'API v1 Roadmap' });
    const docId = createRes.body.data.document.id;

    // Alice invites Bob as editor
    await request(app)
      .post(`/api/documents/${docId}/share/invite`)
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ email: bobEmail, role: 'editor' });

    // Alice invites Charlie as viewer
    await request(app)
      .post(`/api/documents/${docId}/share/invite`)
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ email: charlieEmail, role: 'viewer' });

    // Bob (Editor) renames doc
    const bobRenameRes = await request(app)
      .patch(`/api/documents/${docId}`)
      .set('Authorization', `Bearer ${bobToken}`)
      .send({ title: 'API v2 Roadmap (Updated by Bob)' });
    expect(bobRenameRes.status).toBe(200);
    expect(bobRenameRes.body.data.document.title).toBe('API v2 Roadmap (Updated by Bob)');

    // Charlie (Viewer) attempts rename -> 403 Forbidden!
    const charlieRenameRes = await request(app)
      .patch(`/api/documents/${docId}`)
      .set('Authorization', `Bearer ${charlieToken}`)
      .send({ title: 'Hacked by Charlie' });
    expect(charlieRenameRes.status).toBe(403);
    expect(charlieRenameRes.body.error.message).toContain('Insufficient permissions');
  });

  it('manages share links: creation, redemption, and revocation', async () => {
    const createRes = await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ title: 'Shared Architecture Doc' });
    const docId = createRes.body.data.document.id;

    // Create share link for viewers
    const linkRes = await request(app)
      .post(`/api/documents/${docId}/share/links`)
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ role: 'viewer', expiresInDays: 7 });

    expect(linkRes.status).toBe(201);
    const token = linkRes.body.data.token;
    expect(token).toBeDefined();

    // Charlie joins document via share link
    const joinRes = await request(app)
      .post(`/api/share/join/${token}`)
      .set('Authorization', `Bearer ${charlieToken}`);

    expect(joinRes.status).toBe(200);
    expect(joinRes.body.data.role).toBe('viewer');

    // Charlie can now access document metadata
    const accessRes = await request(app)
      .get(`/api/documents/${docId}`)
      .set('Authorization', `Bearer ${charlieToken}`);
    expect(accessRes.status).toBe(200);
    expect(accessRes.body.data.document.role).toBe('viewer');

    // Alice revokes the share link
    const revokeRes = await request(app)
      .delete(`/api/documents/${docId}/share/links/${token}`)
      .set('Authorization', `Bearer ${aliceToken}`);
    expect(revokeRes.status).toBe(200);

    // Another user attempting to use the revoked link is blocked
    const newJoinRes = await request(app)
      .post(`/api/share/join/${token}`)
      .set('Authorization', `Bearer ${bobToken}`);
    expect(newJoinRes.status).toBe(403);
    expect(newJoinRes.body.error.message).toContain('revoked');
  });

  it('handles soft delete and document restoration', async () => {
    const createRes = await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ title: 'To Be Deleted' });
    const docId = createRes.body.data.document.id;

    // Soft delete
    const delRes = await request(app)
      .delete(`/api/documents/${docId}`)
      .set('Authorization', `Bearer ${aliceToken}`);
    expect(delRes.status).toBe(200);

    // Querying deleted document returns 404
    const getRes = await request(app)
      .get(`/api/documents/${docId}`)
      .set('Authorization', `Bearer ${aliceToken}`);
    expect(getRes.status).toBe(404);

    // Restore document
    const restoreRes = await request(app)
      .post(`/api/documents/${docId}/restore`)
      .set('Authorization', `Bearer ${aliceToken}`);
    expect(restoreRes.status).toBe(200);

    // Accessible again
    const postRestoreRes = await request(app)
      .get(`/api/documents/${docId}`)
      .set('Authorization', `Bearer ${aliceToken}`);
    expect(postRestoreRes.status).toBe(200);
    expect(postRestoreRes.body.data.document.title).toBe('To Be Deleted');
  });

  it('lists documents in dashboard with pagination and search', async () => {
    // Create 3 documents
    await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ title: 'React Guide' });
    await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ title: 'Node.js Security' });
    await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${aliceToken}`)
      .send({ title: 'GraphQL vs REST' });

    // Fetch mine with search
    const searchRes = await request(app)
      .get('/api/documents/mine?search=Security')
      .set('Authorization', `Bearer ${aliceToken}`);

    expect(searchRes.status).toBe(200);
    expect(searchRes.body.data.documents).toHaveLength(1);
    expect(searchRes.body.data.documents[0].title).toBe('Node.js Security');

    // Fetch mine with pagination
    const pageRes = await request(app)
      .get('/api/documents/mine?page=1&limit=2')
      .set('Authorization', `Bearer ${aliceToken}`);

    expect(pageRes.status).toBe(200);
    expect(pageRes.body.data.documents).toHaveLength(2);
    expect(pageRes.body.data.pagination.total).toBe(3);
    expect(pageRes.body.data.pagination.totalPages).toBe(2);
  });
});

