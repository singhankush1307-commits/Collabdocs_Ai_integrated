import { describe, it, expect } from 'vitest';
import { callGemini, callOpenAI } from '../src/services/aiProviders.js';

const reply = (status, body) => async () => ({
  ok: status < 400,
  status,
  text: async () => JSON.stringify(body),
});

const base = { apiKey: 'KEY', model: 'gemini-2.5-flash-lite', systemInstruction: 's', userContent: 'u' };

describe('AI providers (stubbed fetch, no network)', () => {
  it('Gemini: joins text parts and sends the key in a header, not the URL', async () => {
    let seen;
    const text = await callGemini({
      ...base,
      fetchImpl: async (url, opts) => {
        seen = { url, opts };
        return reply(200, { candidates: [{ content: { parts: [{ text: 'Hello ' }, { text: 'world' }] } }] })();
      },
    });
    expect(text).toBe('Hello world');
    expect(seen.url).not.toContain('KEY');
    expect(seen.opts.headers['x-goog-api-key']).toBe('KEY');
  });

  it('Gemini: maps a rejected key to a clear 502 error', async () => {
    await expect(
      callGemini({ ...base, fetchImpl: reply(400, { error: { message: 'API key not valid.' } }) })
    ).rejects.toMatchObject({ statusCode: 502, code: 'AI_PROVIDER_ERROR' });
  });

  it('Gemini: maps unknown model to a 502 that mentions AI_MODEL_NAME', async () => {
    await expect(callGemini({ ...base, fetchImpl: reply(404, { error: { message: 'not found' } }) })).rejects.toThrow(
      /AI_MODEL_NAME/
    );
  });

  it('Gemini: maps upstream 429 to 429', async () => {
    await expect(callGemini({ ...base, fetchImpl: reply(429, {}) })).rejects.toMatchObject({ statusCode: 429 });
  });

  it('Gemini: empty or blocked responses become a 422', async () => {
    await expect(
      callGemini({ ...base, fetchImpl: reply(200, { promptFeedback: { blockReason: 'SAFETY' } }) })
    ).rejects.toMatchObject({ statusCode: 422, code: 'AI_EMPTY_RESPONSE' });
  });

  it('OpenAI: returns message content and maps 401', async () => {
    const ok = await callOpenAI({ ...base, model: 'gpt-4o-mini', fetchImpl: reply(200, { choices: [{ message: { content: 'Hi' } }] }) });
    expect(ok).toBe('Hi');
    await expect(
      callOpenAI({ ...base, model: 'gpt-4o-mini', fetchImpl: reply(401, { error: { message: 'bad' } }) })
    ).rejects.toMatchObject({ statusCode: 502 });
  });
});
