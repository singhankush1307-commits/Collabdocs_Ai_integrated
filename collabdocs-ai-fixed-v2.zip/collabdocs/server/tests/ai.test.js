import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import './setup.js';
import { User } from '../src/models/User.js';

describe('Phase 6: AI Features (Summarize / Rewrite / Grammar)', () => {
  const app = createApp();

  let ownerToken;
  let viewerToken;
  let docId;
  let ownerUser;

  beforeEach(async () => {
    // Owner
    const ownerRes = await request(app).post('/api/auth/register').send({
      name: 'Dr. Jane AI',
      email: 'jane_ai@example.com',
      password: 'Password123!@#',
    });
    ownerToken = ownerRes.body.data.accessToken;
    ownerUser = ownerRes.body.data.user;

    // Viewer
    const viewerRes = await request(app).post('/api/auth/register').send({
      name: 'Bob Viewer',
      email: 'bob_viewer@example.com',
      password: 'Password123!@#',
    });
    viewerToken = viewerRes.body.data.accessToken;

    // Create Document
    const docRes = await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({ title: 'AI Integration Spec' });
    docId = docRes.body.data.document.id;

    // Invite Bob as Viewer
    await request(app)
      .post(`/api/documents/${docId}/share/invite`)
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({ email: 'bob_viewer@example.com', role: 'viewer' });
  });

  it('performs summarization on selected text', async () => {
    const text =
      'Real-time collaborative editing relies on Conflict-free Replicated Data Types (CRDTs). Unlike Operational Transformation which requires a centralized server to order operations, CRDTs allow mathematical convergence across distributed nodes.';

    const res = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({
        documentId: docId,
        text,
        action: 'summarize',
      });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.action).toBe('summarize');
    expect(res.body.data.suggestedText).toContain('Summary:');
    expect(res.body.data).toHaveProperty('remainingDailyQuota');
  });

  it('rewrites text with formal and concise tones', async () => {
    const text = 'in order to make things faster at this point in time';

    // Concise
    const conciseRes = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({
        documentId: docId,
        text,
        action: 'rewrite',
        tone: 'concise',
      });

    expect(conciseRes.status).toBe(200);
    expect(conciseRes.body.data.suggestedText).toBe('to make things faster now');

    // Formal
    const formalRes = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({
        documentId: docId,
        text: 'we should build this thing.',
        action: 'rewrite',
        tone: 'formal',
      });

    expect(formalRes.status).toBe(200);
    expect(formalRes.body.data.suggestedText).toContain('It should be noted that');
  });

  it('fixes grammar and punctuation', async () => {
    const text = 'this sentence has no capitalization and punctuation';

    const res = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({
        documentId: docId,
        text,
        action: 'fix_grammar',
      });

    expect(res.status).toBe(200);
    expect(res.body.data.suggestedText).toBe('This sentence has no capitalization and punctuation.');
  });

  it('rejects a malformed documentId with a clear 400 (not a CastError)', async () => {
    const res = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({
        documentId: 'undefined',
        text: 'Some text long enough to transform.',
        action: 'summarize',
      });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
    expect(JSON.stringify(res.body.error.details)).toContain('documentId');
  });

  it('enforces RBAC: Viewers cannot trigger AI transformations', async () => {
    const res = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${viewerToken}`)
      .send({
        documentId: docId,
        text: 'Some test text for transformation',
        action: 'summarize',
      });

    expect(res.status).toBe(403);
    expect(res.body.error.message).toContain('Insufficient permissions');
  });

  it('rejects text that is too short or exceeds length cap', async () => {
    // Too short
    const shortRes = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({
        documentId: docId,
        text: 'abc', // < 5 chars
        action: 'summarize',
      });
    expect(shortRes.status).toBe(400);

    // Too long
    const hugeText = 'a'.repeat(5001);
    const longRes = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({
        documentId: docId,
        text: hugeText,
        action: 'summarize',
      });
    expect(longRes.status).toBe(400);
  });

  it('enforces daily quota limit per user', async () => {
    // Exhaust user quota
    await User.updateOne(
      { _id: ownerUser.id },
      { 'aiUsage.count': 50, 'aiUsage.date': new Date().toISOString().slice(0, 10) }
    );

    const res = await request(app)
      .post('/api/ai/transform')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({
        documentId: docId,
        text: 'Valid text for transformation',
        action: 'summarize',
      });

    expect(res.status).toBe(429);
    expect(res.body.error.message).toContain('Daily AI transformation quota reached');
  });
});

