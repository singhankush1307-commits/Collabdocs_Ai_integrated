import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: '0.0.0.0',
    proxy: {
      '/api': {
        // Use 127.0.0.1 (not "localhost"): on Node 17+ "localhost" may resolve to ::1 (IPv6)
        // while the server listens on 0.0.0.0 (IPv4 only), causing ECONNREFUSED -> 500.
        target: 'http://127.0.0.1:5000',
        changeOrigin: true,
        configure: (proxy) => {
          proxy.on('error', (err, _req, res) => {
            if (res && !res.headersSent && typeof res.writeHead === 'function') {
              res.writeHead(502, { 'Content-Type': 'application/json' });
              res.end(
                JSON.stringify({
                  success: false,
                  error: {
                    code: 'BACKEND_UNAVAILABLE',
                    message:
                      'Cannot reach the API server on port 5000. Make sure the server and MongoDB are running.',
                  },
                })
              );
            }
          });
        },
      },
      '/socket.io': {
        target: 'http://127.0.0.1:5000',
        changeOrigin: true,
        ws: true,
      },
    },
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
          editor: ['@tiptap/react', '@tiptap/starter-kit'],
          yjs: ['yjs', 'lib0'],
        },
      },
    },
  },
});

