import { io as createSocket } from 'socket.io-client';
import * as Y from 'yjs';
import * as syncProtocol from 'y-protocols/sync';
import * as awarenessProtocol from 'y-protocols/awareness';
import * as encoding from 'lib0/encoding';
import * as decoding from 'lib0/decoding';

function toUint8Array(data) {
  if (!data) return new Uint8Array(0);
  if (data.constructor === Uint8Array) return data;
  const buf = data.buffer ? data : new Uint8Array(data);
  return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
}

export class SocketIoYjsProvider {
  constructor({
    url = '',
    documentId,
    doc,
    token,
    user = { name: 'Anonymous', avatarColor: '#3b82f6' },
  }) {
    this.url = url || window.location.origin;
    this.documentId = documentId;
    this.doc = doc;
    this.token = token;
    this.user = user;

    this.awareness = new awarenessProtocol.Awareness(this.doc);
    this.connected = false;
    this.synced = false;
    this.offlineQueue = [];
    this.listeners = new Map();

    // Set initial awareness state
    this.awareness.setLocalStateField('user', {
      name: user.name || 'Anonymous',
      color: user.avatarColor || '#3b82f6',
    });

    this.initSocket();
    this.bindDocEvents();
    this.bindAwarenessEvents();
  }

  on(event, handler) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event).add(handler);
    return () => this.off(event, handler);
  }

  off(event, handler) {
    const handlers = this.listeners.get(event);
    if (handlers) {
      handlers.delete(handler);
    }
  }

  emit(event, ...args) {
    const handlers = this.listeners.get(event);
    if (handlers) {
      for (const handler of handlers) {
        try {
          handler(...args);
        } catch (err) {
          console.error(`Error in event listener for ${event}:`, err);
        }
      }
    }
  }

  initSocket() {
    this.socket = createSocket(this.url, {
      auth: { token: this.token },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 20,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
    });

    this.emit('status', 'connecting');

    this.socket.on('connect', () => {
      this.connected = true;
      this.emit('status', 'connected');

      // Join document room
      this.socket.emit('join-document', { documentId: this.documentId }, (ack) => {
        if (!ack?.success) {
          this.emit('error', ack?.error || 'Failed to join document');
          return;
        }

        this.role = ack.data.role;
        this.emit('joined', ack.data);

        // Send Sync Step 1 to server
        const encoder = encoding.createEncoder();
        encoding.writeVarUint(encoder, 0); // messageSync = 0
        syncProtocol.writeSyncStep1(encoder, this.doc);
        this.sendSyncMessage(encoding.toUint8Array(encoder));

        // Flush offline queue on reconnect
        if (this.offlineQueue.length > 0) {
          const queued = [...this.offlineQueue];
          this.offlineQueue = [];
          for (const update of queued) {
            const upEncoder = encoding.createEncoder();
            encoding.writeVarUint(upEncoder, 0);
            syncProtocol.writeUpdate(upEncoder, update);
            this.sendSyncMessage(encoding.toUint8Array(upEncoder));
          }
        }
      });
    });

    this.socket.on('disconnect', (reason) => {
      this.connected = false;
      this.synced = false;
      this.emit('status', 'offline');
      this.emit('synced', false);
    });

    this.socket.on('connect_error', (err) => {
      this.connected = false;
      this.emit('status', 'reconnecting');
      this.emit('error', err.message);
    });

    // Handle incoming Yjs Sync messages from server
    this.socket.on('sync-message', ({ documentId, payload }) => {
      if (documentId !== this.documentId || !payload) return;

      const uint8 = toUint8Array(payload);
      const decoder = decoding.createDecoder(uint8);
      const encoder = encoding.createEncoder();
      const messageType = decoding.readVarUint(decoder);

      if (messageType === 0) {
        // Sync message
        encoding.writeVarUint(encoder, 0);
        const syncMessageType = syncProtocol.readSyncMessage(
          decoder,
          encoder,
          this.doc,
          this
        );

        if (syncMessageType === 0) {
          // Received SyncStep1, send reply with SyncStep2
          this.sendSyncMessage(encoding.toUint8Array(encoder));
        }

        if (!this.synced) {
          this.synced = true;
          this.emit('synced', true);
        }
      }
    });

    // Handle Awareness updates from other collaborators
    this.socket.on('awareness-update', ({ documentId, payload }) => {
      if (documentId !== this.documentId || !payload) return;
      const uint8 = toUint8Array(payload);
      awarenessProtocol.applyAwarenessUpdate(this.awareness, uint8, this);
    });

    // Handle Room Presence avatars
    this.socket.on('room-presence', ({ documentId, activeUsers }) => {
      if (documentId !== this.documentId) return;
      this.emit('presence', activeUsers || []);
    });

    // Handle permission error (e.g. viewer write rejection)
    this.socket.on('permission-error', (err) => {
      this.emit('permission-error', err);
    });
  }

  sendSyncMessage(uint8Array) {
    if (this.socket && this.connected) {
      this.socket.emit('sync-message', {
        documentId: this.documentId,
        payload: uint8Array,
      });
    }
  }

  bindDocEvents() {
    this.doc.on('update', (update, origin) => {
      // Ignore updates applied from remote
      if (origin === this) return;

      if (this.socket && this.connected) {
        const encoder = encoding.createEncoder();
        encoding.writeVarUint(encoder, 0); // messageSync = 0
        syncProtocol.writeUpdate(encoder, update);
        this.sendSyncMessage(encoding.toUint8Array(encoder));
      } else {
        // Queue update for offline merge on reconnect
        this.offlineQueue.push(update);
      }
    });
  }

  bindAwarenessEvents() {
    let awarenessTimeout = null;

    this.awareness.on('update', ({ added, updated, removed }, origin) => {
      if (origin === this) return;

      const changedClients = added.concat(updated, removed);
      if (changedClients.length === 0) return;

      // Throttle awareness emissions by 50ms
      if (!awarenessTimeout) {
        awarenessTimeout = setTimeout(() => {
          awarenessTimeout = null;
          if (this.socket && this.connected) {
            const awarenessUpdate = awarenessProtocol.encodeAwarenessUpdate(
              this.awareness,
              changedClients
            );
            this.socket.emit('awareness-update', {
              documentId: this.documentId,
              payload: awarenessUpdate,
            });
          }
        }, 50);
      }
    });
  }

  destroy() {
    if (this.socket) {
      this.socket.emit('leave-document', { documentId: this.documentId });
      this.socket.disconnect();
    }
    this.awareness.destroy();
    this.listeners.clear();
  }
}

