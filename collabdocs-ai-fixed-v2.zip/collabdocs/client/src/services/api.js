const API_URL = import.meta.env.VITE_API_URL || '/api';

class ApiClient {
  constructor() {
    this.accessToken = null;
    this.refreshPromise = null;
    this.onUnauthenticated = null;
  }

  setToken(token) {
    this.accessToken = token;
  }

  getToken() {
    return this.accessToken;
  }

  clearToken() {
    this.accessToken = null;
  }

  async request(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      'X-Requested-With': 'CollabDocs',
      ...(options.headers || {}),
    };

    if (this.accessToken && !headers.Authorization) {
      headers.Authorization = `Bearer ${this.accessToken}`;
    }

    const config = {
      ...options,
      headers,
      credentials: 'include', // sends httpOnly cookies
    };

    let response = await fetch(url, config);

    // If 401 Unauthorized and not already calling refresh or login
    if (response.status === 401 && !endpoint.includes('/auth/login') && !endpoint.includes('/auth/refresh')) {
      try {
        const newAccessToken = await this.refreshToken();
        if (newAccessToken) {
          headers.Authorization = `Bearer ${newAccessToken}`;
          config.headers = headers;
          response = await fetch(url, config);
        }
      } catch (err) {
        this.clearToken();
        if (typeof this.onUnauthenticated === 'function') {
          this.onUnauthenticated();
        }
        throw err;
      }
    }

    let data = {};
    try {
      data = await response.json();
    } catch {
      data = {};
    }
    if (!response.ok) {
      const error = new Error(
        data.error?.message ||
          (response.status >= 500
            ? 'Server is unavailable. Please make sure the backend and MongoDB are running.'
            : 'Request failed')
      );
      error.code = data.error?.code;
      error.status = response.status;
      error.details = data.error?.details;
      throw error;
    }

    return data;
  }

  async refreshToken() {
    if (this.refreshPromise) {
      return this.refreshPromise;
    }

    this.refreshPromise = (async () => {
      try {
        const res = await fetch(`${API_URL}/auth/refresh`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'CollabDocs',
          },
          credentials: 'include',
        });

        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          throw new Error(data.error?.message || 'Session expired');
        }

        const newAccessToken = data.data.accessToken;
        this.setToken(newAccessToken);
        return newAccessToken;
      } finally {
        this.refreshPromise = null;
      }
    })();

    return this.refreshPromise;
  }

  // Convenience HTTP methods
  get(endpoint, options = {}) {
    return this.request(endpoint, { ...options, method: 'GET' });
  }

  post(endpoint, body, options = {}) {
    return this.request(endpoint, {
      ...options,
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  patch(endpoint, body, options = {}) {
    return this.request(endpoint, {
      ...options,
      method: 'PATCH',
      body: JSON.stringify(body),
    });
  }

  delete(endpoint, options = {}) {
    return this.request(endpoint, { ...options, method: 'DELETE' });
  }
}

export const api = new ApiClient();

