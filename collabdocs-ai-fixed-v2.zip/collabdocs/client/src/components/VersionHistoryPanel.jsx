import React, { useEffect, useState } from 'react';
import { X, RotateCcw, ChevronRight, Clock, Tag } from 'lucide-react';
import { api } from '../services/api.js';

function formatDate(iso) {
  return new Date(iso).toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function VersionHistoryPanel({ docId, onClose, onRestore }) {
  const [versions, setVersions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [restoring, setRestoring] = useState(null);

  useEffect(() => {
    async function fetchVersions() {
      try {
        const res = await api.get(`/documents/${docId}/versions`);
        setVersions(res.data.versions || []);
      } catch (err) {
        console.error('Failed to load versions', err);
      } finally {
        setLoading(false);
      }
    }
    fetchVersions();
  }, [docId]);

  const handleRestore = async (version) => {
    if (!confirm(`Restore version ${version}? The current content will be replaced.`)) return;
    setRestoring(version);
    try {
      await api.post(`/documents/${docId}/versions/${version}/restore`);
      onRestore?.();
    } catch (err) {
      alert(err.message || 'Failed to restore version.');
    } finally {
      setRestoring(null);
    }
  };

  return (
    <aside className="flex flex-col h-full border-l border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 w-72 shrink-0">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-gray-400" />
          <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Version History</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-gray-400 hover:text-gray-700 dark:hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Version list */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center py-10">
            <div className="w-5 h-5 border-2 border-brand-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : versions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 px-4 text-center">
            <Clock className="w-8 h-8 text-gray-300 dark:text-gray-600 mb-2" />
            <p className="text-xs text-gray-400">No versions saved yet.</p>
          </div>
        ) : (
          <ul className="divide-y divide-gray-100 dark:divide-gray-800">
            {versions.map((v) => (
              <li key={v.version} className="px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800/50 group">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-xs font-semibold text-gray-900 dark:text-white">
                        v{v.version}
                      </span>
                      {v.label && (
                        <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 text-[10px] font-medium">
                          <Tag className="w-2.5 h-2.5" />
                          {v.label}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{formatDate(v.createdAt)}</p>
                    {v.createdBy?.name && (
                      <p className="text-[11px] text-gray-400 mt-0.5">by {v.createdBy.name}</p>
                    )}
                  </div>
                  <button
                    onClick={() => handleRestore(v.version)}
                    disabled={restoring === v.version}
                    title="Restore this version"
                    className="shrink-0 opacity-0 group-hover:opacity-100 p-1.5 rounded-lg text-gray-400 hover:text-brand-600 hover:bg-brand-50 dark:hover:bg-brand-900/20 transition-all disabled:opacity-50"
                  >
                    {restoring === v.version ? (
                      <span className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin inline-block" />
                    ) : (
                      <RotateCcw className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </aside>
  );
}

