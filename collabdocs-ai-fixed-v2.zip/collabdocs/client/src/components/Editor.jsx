import React from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import Collaboration from '@tiptap/extension-collaboration';
import CollaborationCursor from '@tiptap/extension-collaboration-cursor';
import { EditorToolbar } from './EditorToolbar.jsx';

/**
 * CollaborativeEditor
 *
 * @param {Object} props
 * @param {Y.Doc} props.ydoc
 * @param {import('../services/SocketIoYjsProvider.js').SocketIoYjsProvider} props.provider
 * @param {Object} props.user  - { name, avatarColor }
 * @param {boolean} props.readOnly
 * @param {Function} [props.onEditorReady]  - called with the editor instance
 */
export function CollaborativeEditor({ ydoc, provider, user, readOnly = false, onEditorReady }) {
  const editor = useEditor({
    editable: !readOnly,
    extensions: [
      StarterKit.configure({
        // History is managed by Yjs Undo Manager
        history: false,
      }),
      Underline,
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          rel: 'noopener noreferrer',
          target: '_blank',
          class: 'text-brand-600 dark:text-brand-400 underline hover:no-underline',
        },
      }),
      Table.configure({ resizable: true }),
      TableRow,
      TableCell,
      TableHeader,
      Collaboration.configure({ document: ydoc }),
      CollaborationCursor.configure({
        provider,
        user: {
          name: user?.name || 'Anonymous',
          color: user?.avatarColor || '#3b82f6',
        },
      }),
    ],
    editorProps: {
      attributes: {
        class: 'ProseMirror focus:outline-none',
        spellcheck: 'true',
        'data-gramm': 'false',
      },
    },
    onCreate({ editor }) {
      if (onEditorReady) onEditorReady(editor);
    },
  });

  return (
    <div className="flex flex-col h-full">
      {!readOnly && <EditorToolbar editor={editor} />}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-6 py-8">
          <EditorContent editor={editor} />
        </div>
      </div>
    </div>
  );
}

