import React, { useState } from 'react';
import { X, Copy, Check, UserMinus, Link2, Trash2, Plus } from 'lucide-react';
import { api } from '../services/api.js';

export function ShareModal({ docId, onClose }) {
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('editor');
  const [inviting, setInviting] = useState(false);
  const [inviteError, setInviteError] = useState('');

  const [shareLink, setShareLink] = useState(null);
  const [linkRole, setLinkRole] = useState('viewer');
  const [creatingLink, setCreatingLink] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleInvite = async (e) => {
    e.preventDefault();
    setInviteError('');
    setInviting(true);
    try {
      await api.post(`/documents/${docId}/share/invite`, {
        email: inviteEmail,
        role: inviteRole,
      });
      setInviteEmail('');
      alert(`Invitation sent to ${inviteEmail}`);
    } catch (err) {
      setInviteError(err.message || 'Failed to invite collaborator.');
    } finally {
      setInviting(false);
    }
  };

  const handleCreateLink = async () => {
    setCreatingLink(true);
    try {
      const res = await api.post(`/documents/${docId}/share/links`, { role: linkRole });
      const { token } = res.data.shareLink;
      const url = `${window.location.origin}/join/${token}`;
      setShareLink(url);
    } catch (err) {
      alert(err.message || 'Failed to create share link');
    } finally {
      setCreatingLink(false);
    }
  };

  const handleCopy = () => {
    if (!shareLink) return;
    navigator.clipboard.writeText(shareLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-800 w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-800">
          <h2 className="font-semibold text-gray-900 dark:text-white">Share Document</h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Invite by email */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
              Invite by email
            </h3>
            <form onSubmit={handleInvite} className="flex gap-2">
              <input
                type="email"
                required
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="colleague@example.com"
                className="flex-1 px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
              />
              <select
                value={inviteRole}
                onChange={(e) => setInviteRole(e.target.value)}
                className="px-2 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              >
                <option value="editor">Editor</option>
                <option value="commenter">Commenter</option>
                <option value="viewer">Viewer</option>
              </select>
              <button
                type="submit"
                disabled={inviting}
                className="px-3 py-2 bg-brand-600 hover:bg-brand-700 disabled:opacity-60 text-white text-sm font-semibold rounded-lg transition-colors flex items-center gap-1"
              >
                {inviting ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Plus className="w-4 h-4" />
                )}
                Invite
              </button>
            </form>
            {inviteError && (
              <p className="mt-2 text-xs text-red-500">{inviteError}</p>
            )}
          </div>

          {/* Share link */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
              Share via link
            </h3>
            <div className="flex gap-2 mb-2">
              <select
                value={linkRole}
                onChange={(e) => setLinkRole(e.target.value)}
                className="px-2 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
              >
                <option value="editor">Editor</option>
                <option value="commenter">Commenter</option>
                <option value="viewer">Viewer</option>
              </select>
              <button
                onClick={handleCreateLink}
                disabled={creatingLink}
                className="flex-1 flex items-center justify-center gap-2 px-3 py-2 border border-gray-300 dark:border-gray-700 hover:border-brand-400 text-sm text-gray-700 dark:text-gray-300 hover:text-brand-600 rounded-lg transition-colors disabled:opacity-60"
              >
                {creatingLink ? (
                  <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Link2 className="w-4 h-4" />
                )}
                Generate link
              </button>
            </div>

            {shareLink && (
              <div className="flex items-center gap-2 mt-2">
                <input
                  readOnly
                  value={shareLink}
                  className="flex-1 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-xs text-gray-600 dark:text-gray-400 font-mono focus:outline-none"
                />
                <button
                  onClick={handleCopy}
                  className="p-2 rounded-lg border border-gray-200 dark:border-gray-700 text-gray-500 hover:text-brand-600 hover:border-brand-400 transition-colors"
                  title="Copy link"
                >
                  {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

