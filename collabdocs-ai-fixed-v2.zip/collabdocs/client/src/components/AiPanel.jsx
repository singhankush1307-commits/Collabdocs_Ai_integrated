import React, { useState } from 'react';
import { X, Sparkles, Loader2, Copy, Check, ChevronDown } from 'lucide-react';
import { api } from '../services/api.js';

const ACTIONS = [
  { value: 'summarize', label: 'Summarize', hint: 'Get a concise summary of selected text' },
  { value: 'rewrite', label: 'Rewrite', hint: 'Rephrase the selected text' },
  { value: 'fix_grammar', label: 'Fix Grammar', hint: 'Correct grammar and spelling' },
];

const TONES = [
  { value: 'formal', label: 'Formal' },
  { value: 'concise', label: 'Concise' },
  { value: 'friendly', label: 'Friendly' },
];

// The server HTML-sanitizes AI output (so "&" arrives as "&amp;").
// Decode it for plain-text display; DOMParser never executes scripts.
function toPlainText(html) {
  return new DOMParser().parseFromString(html, 'text/html').documentElement.textContent || '';
}

export function AiPanel({ docId, selectedText, onApply, onClose }) {
  const [action, setAction] = useState('summarize');
  const [tone, setTone] = useState('formal');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(''); // sanitized text from the server (what we insert)
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const handleTransform = async () => {
    if (!selectedText || selectedText.trim().length < 5) {
      setError('Please select at least 5 characters of text in the editor.');
      return;
    }
    if (!docId || !/^[a-f\d]{24}$/i.test(docId)) {
      setError('This document has an invalid ID. Go back to the dashboard and reopen it.');
      return;
    }
    setError('');
    setResult('');
    setLoading(true);
    try {
      const res = await api.post('/ai/transform', {
        documentId: docId,
        text: selectedText,
        action,
        tone,
      });
      setResult(res.data.suggestedText || '');
    } catch (err) {
      const detail = Array.isArray(err.details)
        ? err.details.map((d) => `${d.field ? `${d.field}: ` : ''}${d.message}`).join(' · ')
        : '';
      setError([err.message || 'AI transformation failed. Please try again.', detail].filter(Boolean).join(' — '));
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(toPlainText(result));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApply = () => {
    if (result && onApply) {
      onApply(result);
      setResult('');
    }
  };

  return (
    <aside className="flex flex-col h-full border-l border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 w-80 shrink-0">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-brand-600 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-white" />
          </div>
          <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300">AI Assistant</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-gray-400 hover:text-gray-700 dark:hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Selected text preview */}
        <div>
          <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">
            Selected text
          </label>
          <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs text-gray-600 dark:text-gray-400 max-h-28 overflow-y-auto leading-relaxed">
            {selectedText ? (
              <span className="line-clamp-6">{selectedText}</span>
            ) : (
              <span className="text-gray-400 italic">Select text in the document to use AI features.</span>
            )}
          </div>
        </div>

        {/* Action */}
        <div>
          <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">
            Action
          </label>
          <div className="space-y-1.5">
            {ACTIONS.map((a) => (
              <label key={a.value} className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                action === a.value
                  ? 'border-brand-400 bg-brand-50/60 dark:bg-brand-900/20 dark:border-brand-500'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
              }`}>
                <input
                  type="radio"
                  name="action"
                  value={a.value}
                  checked={action === a.value}
                  onChange={() => setAction(a.value)}
                  className="mt-0.5 accent-brand-600"
                />
                <div>
                  <div className="text-xs font-semibold text-gray-800 dark:text-gray-200">{a.label}</div>
                  <div className="text-[11px] text-gray-400 mt-0.5">{a.hint}</div>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Tone (only relevant for rewrite/fix_grammar) */}
        {(action === 'rewrite' || action === 'fix_grammar') && (
          <div>
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">
              Tone
            </label>
            <div className="flex gap-1.5 flex-wrap">
              {TONES.map((t) => (
                <button
                  key={t.value}
                  onClick={() => setTone(t.value)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                    tone === t.value
                      ? 'bg-brand-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Transform button */}
        <button
          onClick={handleTransform}
          disabled={loading || !selectedText}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-brand-600 hover:bg-brand-700 disabled:opacity-50 text-white text-sm font-semibold transition-colors"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Processing…
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              Transform
            </>
          )}
        </button>

        {/* Error */}
        {error && (
          <div className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 text-xs">
            {error}
          </div>
        )}

        {/* Result */}
        {result && (
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-gray-500 dark:text-gray-400">Result</label>
              <div className="flex gap-1">
                <button
                  onClick={handleCopy}
                  title="Copy result"
                  className="p-1.5 rounded-md text-gray-400 hover:text-gray-700 dark:hover:text-white transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs text-gray-800 dark:text-gray-200 leading-relaxed whitespace-pre-wrap max-h-48 overflow-y-auto">
              {toPlainText(result)}
            </div>
            {onApply && (
              <button
                onClick={handleApply}
                className="mt-2 w-full py-2 px-4 rounded-lg border border-brand-500 text-brand-600 dark:text-brand-400 text-xs font-semibold hover:bg-brand-50 dark:hover:bg-brand-900/20 transition-colors"
              >
                Replace selection with result
              </button>
            )}
          </div>
        )}
      </div>
    </aside>
  );
}

