import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import * as Y from 'yjs';
import { useAuth } from '../context/AuthContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import { api } from '../services/api.js';
import { SocketIoYjsProvider } from '../services/SocketIoYjsProvider.js';
import { CollaborativeEditor } from '../components/Editor.jsx';
import { ShareModal } from '../components/ShareModal.jsx';
import { VersionHistoryPanel } from '../components/VersionHistoryPanel.jsx';
import { AiPanel } from '../components/AiPanel.jsx';
import {
  ArrowLeft, Share2, Clock, Sparkles, Sun, Moon, Wifi, WifiOff,
  Save, AlertCircle, CheckCircle2, Loader2, Edit3, Users,
} from 'lucide-react';

function StatusBadge({ status }) {
  const map = {
    connecting: { icon: Loader2, text: 'Connecting', className: 'text-yellow-500 dark:text-yellow-400' },
    connected: { icon: Wifi, text: 'Connected', className: 'text-green-500 dark:text-green-400' },
    offline: { icon: WifiOff, text: 'Offline', className: 'text-red-500 dark:text-red-400' },
    reconnecting: { icon: Loader2, text: 'Reconnecting', className: 'text-yellow-500 dark:text-yellow-400' },
    synced: { icon: CheckCircle2, text: 'Synced', className: 'text-green-500 dark:text-green-400' },
  };
  const cfg = map[status] || map.connecting;
  const Icon = cfg.icon;
  const spin = status === 'connecting' || status === 'reconnecting';

  return (
    <span className={`flex items-center gap-1 text-xs font-medium ${cfg.className}`}>
      <Icon className={`w-3.5 h-3.5 ${spin ? 'animate-spin' : ''}`} />
      {cfg.text}
    </span>
  );
}

function PresenceAvatars({ users }) {
  if (!users?.length) return null;
  const visible = users.slice(0, 5);
  const extra = users.length - visible.length;
  return (
    <div className="flex items-center -space-x-2">
      {visible.map((u, i) => (
        <div
          key={u.clientId || i}
          title={u.name}
          className="w-7 h-7 rounded-full border-2 border-white dark:border-gray-900 flex items-center justify-center text-white text-[10px] font-semibold shadow-sm"
          style={{ backgroundColor: u.color || '#3b82f6', zIndex: visible.length - i }}
        >
          {(u.name || '?').charAt(0).toUpperCase()}
        </div>
      ))}
      {extra > 0 && (
        <div
          title={`${extra} more collaborators`}
          className="w-7 h-7 rounded-full border-2 border-white dark:border-gray-900 bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-gray-700 dark:text-gray-200 text-[10px] font-semibold"
        >
          +{extra}
        </div>
      )}
    </div>
  );
}

export function EditorPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [doc, setDoc] = useState(null);
  const [loadingDoc, setLoadingDoc] = useState(true);
  const [connStatus, setConnStatus] = useState('connecting');
  const [synced, setSynced] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [title, setTitle] = useState('');
  const [savingTitle, setSavingTitle] = useState(false);
  const [titleError, setTitleError] = useState('');
  const [editingTitle, setEditingTitle] = useState(false);

  const [showShare, setShowShare] = useState(false);
  const [showVersions, setShowVersions] = useState(false);
  const [showAi, setShowAi] = useState(false);
  const [selectedText, setSelectedText] = useState('');

  // Yjs / provider refs
  const ydocRef = useRef(null);
  const providerRef = useRef(null);
  const editorRef = useRef(null);

  // Load document metadata
  useEffect(() => {
    async function loadDoc() {
      try {
        const res = await api.get(`/documents/${id}`);
        const docData = res.data.document;
        setDoc(docData);
        setTitle(docData.title);
      } catch (err) {
        if (err.status === 403 || err.status === 404) {
          navigate('/', { replace: true });
        }
      } finally {
        setLoadingDoc(false);
      }
    }
    loadDoc();
  }, [id, navigate]);

  // Initialize Yjs + SocketIO provider once doc is loaded
  useEffect(() => {
    if (loadingDoc || !user) return;

    const ydoc = new Y.Doc();
    ydocRef.current = ydoc;

    const provider = new SocketIoYjsProvider({
      url: window.location.origin,
      documentId: id,
      doc: ydoc,
      token: api.getToken(),
      user: { name: user.name, avatarColor: user.avatarColor },
    });
    providerRef.current = provider;

    provider.on('status', setConnStatus);
    provider.on('synced', setSynced);
    provider.on('presence', setOnlineUsers);
    provider.on('error', (err) => console.warn('[ColabDocs] socket error:', err));

    return () => {
      provider.destroy();
      ydoc.destroy();
      providerRef.current = null;
      ydocRef.current = null;
    };
  }, [loadingDoc, id, user]);

  // Track selection for AI panel
  const handleEditorReady = useCallback((editor) => {
    editorRef.current = editor;
    editor.on('selectionUpdate', () => {
      const { from, to } = editor.state.selection;
      if (from !== to) {
        setSelectedText(editor.state.doc.textBetween(from, to, ' '));
      } else {
        setSelectedText('');
      }
    });
  }, []);

  // Save title with debounce on blur
  const handleTitleBlur = async () => {
    setEditingTitle(false);
    const trimmed = title.trim();
    if (!trimmed || trimmed === doc?.title) return;
    setSavingTitle(true);
    setTitleError('');
    try {
      await api.patch(`/documents/${id}`, { title: trimmed });
      setDoc((d) => ({ ...d, title: trimmed }));
    } catch (err) {
      setTitleError('Failed to save title');
      setTitle(doc?.title || '');
    } finally {
      setSavingTitle(false);
    }
  };

  // Apply AI result to editor
  const handleApplyAi = useCallback((text) => {
    const editor = editorRef.current;
    if (!editor) return;
    const { from, to } = editor.state.selection;
    if (from !== to) {
      // `text` is already HTML-escaped by the server, so it is safe to wrap in <p>/<br>.
      const html = text
        .split(/\n{2,}/)
        .map((para) => `<p>${para.replace(/\n/g, '<br>')}</p>`)
        .join('');
      editor.chain().focus().deleteRange({ from, to }).insertContentAt(from, html).run();
    }
  }, []);

  // The server resolves the caller's role for us ('owner' | 'editor' | 'commenter' | 'viewer')
  const isOwner = doc?.role === 'owner';
  const isEditor = isOwner || doc?.role === 'editor';

  if (loadingDoc || !ydocRef.current) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-brand-600 animate-spin" />
          <span className="text-sm text-gray-500 dark:text-gray-400">Loading document…</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-950">
      {/* Top bar */}
      <header className="shrink-0 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-4 h-14 flex items-center gap-3 z-20">
        {/* Back */}
        <button
          onClick={() => navigate('/')}
          className="p-2 rounded-lg text-gray-500 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title="Back to dashboard"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="flex-1 min-w-0 flex items-center gap-2">
          {editingTitle && isEditor ? (
            <input
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onBlur={handleTitleBlur}
              onKeyDown={(e) => { if (e.key === 'Enter') e.target.blur(); if (e.key === 'Escape') { setTitle(doc?.title || ''); setEditingTitle(false); } }}
              className="text-sm font-semibold bg-transparent border-b border-brand-400 outline-none text-gray-900 dark:text-white min-w-0 max-w-xs"
            />
          ) : (
            <button
              onClick={() => isEditor && setEditingTitle(true)}
              className={`text-sm font-semibold text-gray-800 dark:text-white truncate max-w-xs ${isEditor ? 'hover:text-brand-600 cursor-text' : 'cursor-default'}`}
              title={isEditor ? 'Click to rename' : title}
            >
              {title || 'Untitled'}
            </button>
          )}
          {savingTitle && <Loader2 className="w-3.5 h-3.5 text-gray-400 animate-spin shrink-0" />}
          {titleError && <span className="text-xs text-red-500">{titleError}</span>}
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <StatusBadge status={synced ? 'synced' : connStatus} />

          <PresenceAvatars users={onlineUsers} />

          {/* Versions */}
          <button
            onClick={() => { setShowVersions((v) => !v); setShowAi(false); }}
            title="Version history"
            className={`p-2 rounded-lg transition-colors text-sm ${showVersions ? 'bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400' : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
          >
            <Clock className="w-4 h-4" />
          </button>

          {/* AI */}
          <button
            onClick={() => { setShowAi((v) => !v); setShowVersions(false); }}
            title="AI Assistant"
            className={`p-2 rounded-lg transition-colors text-sm ${showAi ? 'bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400' : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* Share (owners only) */}
          {isOwner && (
            <button
              onClick={() => setShowShare(true)}
              title="Share document"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              Share
            </button>
          )}

          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Editor area */}
        <div className="flex-1 overflow-y-auto bg-white dark:bg-gray-950">
          {ydocRef.current && providerRef.current && (
            <CollaborativeEditor
              ydoc={ydocRef.current}
              provider={providerRef.current}
              user={user}
              readOnly={!isEditor}
              onEditorReady={handleEditorReady}
            />
          )}
        </div>

        {/* Right panel: Version History or AI */}
        {showVersions && (
          <VersionHistoryPanel
            docId={id}
            onClose={() => setShowVersions(false)}
            onRestore={() => window.location.reload()}
          />
        )}
        {showAi && (
          <AiPanel
            docId={id}
            selectedText={selectedText}
            onApply={isEditor ? handleApplyAi : null}
            onClose={() => setShowAi(false)}
          />
        )}
      </div>

      {/* Share modal */}
      {showShare && <ShareModal docId={id} onClose={() => setShowShare(false)} />}
    </div>
  );
}

