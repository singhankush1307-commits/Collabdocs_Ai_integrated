import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import { api } from '../services/api.js';
import { Navbar } from '../components/Navbar.jsx';
import {
  FilePlus,
  FileText,
  Trash2,
  Users,
  Clock,
  Sun,
  Moon,
  Share2,
} from 'lucide-react';

function DocCard({ doc, onDelete, onOpen }) {
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async (e) => {
    e.stopPropagation();
    if (!confirm(`Delete "${doc.title}"? This cannot be undone.`)) return;
    setDeleting(true);
    try {
      await onDelete(doc.id);
    } finally {
      setDeleting(false);
    }
  };

  const updatedAt = new Date(doc.updatedAt).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div
      onClick={() => onOpen(doc.id)}
      className="group relative bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-5 cursor-pointer hover:border-brand-400 dark:hover:border-brand-500 hover:shadow-md transition-all duration-150"
    >
      <div className="flex items-start gap-3">
        <div className="shrink-0 w-10 h-10 rounded-lg bg-brand-50 dark:bg-brand-900/20 flex items-center justify-center">
          <FileText className="w-5 h-5 text-brand-600 dark:text-brand-400" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-900 dark:text-white truncate text-sm">{doc.title}</h3>
          <div className="flex items-center gap-3 mt-1.5 text-xs text-gray-500 dark:text-gray-400">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {updatedAt}
            </span>
            {doc.collaborators?.length > 0 && (
              <span className="flex items-center gap-1">
                <Users className="w-3 h-3" />
                {doc.collaborators.length} collaborator{doc.collaborators.length !== 1 ? 's' : ''}
              </span>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={handleDelete}
            disabled={deleting}
            aria-label="Delete document"
            className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors disabled:opacity-50"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

export function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [myDocs, setMyDocs] = useState([]);
  const [sharedDocs, setSharedDocs] = useState([]);
  const [loadingMine, setLoadingMine] = useState(true);
  const [loadingShared, setLoadingShared] = useState(true);
  const [creating, setCreating] = useState(false);
  const [tab, setTab] = useState('mine');

  const fetchMine = useCallback(async () => {
    setLoadingMine(true);
    try {
      const res = await api.get('/documents/mine');
      setMyDocs(res.data.documents || []);
    } catch {
      /* ignore */
    } finally {
      setLoadingMine(false);
    }
  }, []);

  const fetchShared = useCallback(async () => {
    setLoadingShared(true);
    try {
      const res = await api.get('/documents/shared');
      setSharedDocs(res.data.documents || []);
    } catch {
      /* ignore */
    } finally {
      setLoadingShared(false);
    }
  }, []);

  useEffect(() => {
    fetchMine();
    fetchShared();
  }, [fetchMine, fetchShared]);

  const handleCreate = async () => {
    setCreating(true);
    try {
      const res = await api.post('/documents', { title: 'Untitled Document' });
      navigate(`/doc/${res.data.document.id}`);
    } catch (err) {
      alert(err.message || 'Failed to create document');
      setCreating(false);
    }
  };

  const handleDelete = async (id) => {
    await api.delete(`/documents/${id}`);
    setMyDocs((docs) => docs.filter((d) => d.id !== id));
  };

  const docs = tab === 'mine' ? myDocs : sharedDocs;
  const loading = tab === 'mine' ? loadingMine : loadingShared;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <Navbar />

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Hello, {user?.name?.split(' ')[0]} 👋
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Manage your documents and collaborate in real time.
            </p>
          </div>
          <button
            onClick={handleCreate}
            disabled={creating}
            className="flex items-center gap-2 px-4 py-2.5 bg-brand-600 hover:bg-brand-700 disabled:opacity-60 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors"
          >
            {creating ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <FilePlus className="w-4 h-4" />
            )}
            New Document
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 border-b border-gray-200 dark:border-gray-800">
          {['mine', 'shared'].map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors ${
                tab === t
                  ? 'border-brand-600 text-brand-600 dark:text-brand-400 dark:border-brand-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              {t === 'mine' ? (
                <>My Documents <span className="ml-1.5 text-xs text-gray-400">({myDocs.length})</span></>
              ) : (
                <>Shared with me <span className="ml-1.5 text-xs text-gray-400">({sharedDocs.length})</span></>
              )}
            </button>
          ))}
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-6 h-6 border-2 border-brand-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : docs.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-4">
              {tab === 'shared' ? (
                <Share2 className="w-7 h-7 text-gray-400" />
              ) : (
                <FileText className="w-7 h-7 text-gray-400" />
              )}
            </div>
            <h3 className="text-base font-semibold text-gray-700 dark:text-gray-300 mb-1">
              {tab === 'shared' ? 'No shared documents yet' : 'No documents yet'}
            </h3>
            <p className="text-sm text-gray-400">
              {tab === 'shared'
                ? 'Documents shared with you will appear here.'
                : 'Create your first document to get started.'}
            </p>
            {tab === 'mine' && (
              <button
                onClick={handleCreate}
                className="mt-4 flex items-center gap-2 px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold rounded-lg transition-colors"
              >
                <FilePlus className="w-4 h-4" />
                New Document
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {docs.map((doc) => (
              <DocCard
                key={doc.id}
                doc={doc}
                onDelete={handleDelete}
                onOpen={(id) => navigate(`/doc/${id}`)}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

