import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../services/api.js';
import { Loader2 } from 'lucide-react';

export function ShareJoinPage() {
  const { token } = useParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState('joining'); // 'joining' | 'error'
  const [error, setError] = useState('');

  useEffect(() => {
    async function joinDocument() {
      try {
        const res = await api.post(`/share/join/${token}`);
        // Redirect to the document
        navigate(`/doc/${res.data.documentId}`, { replace: true });
      } catch (err) {
        setError(err.message || 'Invalid or expired share link.');
        setStatus('error');
      }
    }
    joinDocument();
  }, [token, navigate]);

  if (status === 'error') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-950 px-4">
        <div className="text-center max-w-sm">
          <div className="w-14 h-14 rounded-full bg-red-100 dark:bg-red-900/20 flex items-center justify-center mx-auto mb-4">
            <span className="text-red-500 text-2xl">!</span>
          </div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Link Invalid</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">{error}</p>
          <button
            onClick={() => navigate('/')}
            className="px-5 py-2 bg-brand-600 hover:bg-brand-700 text-white text-sm font-semibold rounded-lg transition-colors"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-950">
      <Loader2 className="w-8 h-8 text-brand-600 animate-spin mb-3" />
      <p className="text-sm text-gray-500 dark:text-gray-400">Joining document…</p>
    </div>
  );
}

